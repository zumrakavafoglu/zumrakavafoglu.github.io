import java.util.Scanner;

//Program for converting angle in degrees to radian
public class AngleConverter {

    public static void main(String[] args){

        double angleInDegrees;

        double angleInRadians;

        final double PI = 3.14;

        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the angle in degrees: ");

        angleInDegrees = scanner.nextDouble();

        angleInRadians = angleInDegrees * PI / 180.0;

        System.out.printf("\n Angle in radians is: %.2f \n",angleInRadians);

        char letter = '6';

        System.out.print(letter);
    }
}

import java.util.Scanner;

public class TimeSplitter {

    public static void main(String[] args) {

        int totalSeconds;

        int hours;

        int minutes;

        int seconds;

        System.out.println("Enter time in seconds: ");

        Scanner input = new Scanner(System.in);

        totalSeconds = input.nextInt();

        hours = totalSeconds / 3600;

        int remainingSeconds = totalSeconds % 3600;

        minutes = remainingSeconds / 60;

        seconds = remainingSeconds % 60;

        System.out.printf("H:%d M:%d S:%d", hours, minutes, seconds);

    }
}

import java.util.Scanner;

public class WordSplitter {

    public static void main(String args[]){

        Scanner input = new Scanner(System.in);

        System.out.print("Enter a two-word sentence: ");

        String word1 = input.next();

        String word2 = input.next();

        System.out.println(word1);
        System.out.print(word2);

    }
}

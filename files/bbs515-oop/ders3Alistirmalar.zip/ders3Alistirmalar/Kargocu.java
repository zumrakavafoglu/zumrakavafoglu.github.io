import java.util.Scanner;

public class Kargocu {
    public static void main(String[] args){

        double weight;

        Scanner input = new Scanner(System.in);

        System.out.println("Kargonun agirligini giriniz: ");

        weight = input.nextDouble();

        double price = 10;

        if(weight <= 0){
            System.out.println("Hatali deger!");
        }else{
            if(weight > 2){
                price += (weight-2)*3.75;
                if(weight > 70){
                    price += 10;
                }
            }
            System.out.printf("Kargo ucreti: %.2f", price);
        }
    }
}

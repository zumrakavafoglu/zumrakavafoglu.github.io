import java.util.Scanner;

public class PartialFunction {

    public static void main(String[] args){

        double x,y;

        Scanner input = new Scanner(System.in);

        System.out.println("Input x");
        x = input.nextDouble();

        System.out.println("Input y");
        y = input.nextDouble();

        double result;

        if(x>=0){
            if(y>=0){
                result = x + y;
            }else{
                result = x + y * y;
            }
        }else{
            if(y>=0){
                result = x * x + y;
            }else{
                result = x * x + y * y;
            }
        }

        System.out.println(result);

    }
}

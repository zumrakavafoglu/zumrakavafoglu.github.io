public class KarmasikSayi {

    private double imajiner;
    private double reel;

    public KarmasikSayi(double _reel, double _imajiner){

        setReel(_reel);
        setImajiner(_imajiner);

    }

    public void setImajiner(double _imajiner){
        imajiner = _imajiner;
    }

    public void setReel(double _reel){
        reel = _reel;
    }

    public double getImajiner() {
        return imajiner;
    }

    public double getReel() {
        return reel;
    }

    public KarmasikSayi topla(KarmasikSayi diger){

        double sonucReel = reel + diger.reel;
        double sonucImajiner = imajiner + diger.imajiner;


        KarmasikSayi sonuc = new KarmasikSayi(sonucReel,sonucImajiner);
        return sonuc;

    }

    public KarmasikSayi carp(KarmasikSayi diger){

        double sonucReel = imajiner*diger.imajiner - reel*diger.reel;
        double sonucImajiner = reel*diger.imajiner + imajiner*diger.reel;


        KarmasikSayi sonuc = new KarmasikSayi(sonucReel,sonucImajiner);
        return sonuc;

    }

    public boolean esitmi(KarmasikSayi diger){

        final double EPS = 1E-7;

        // return reel == diger.reel && imajiner == diger.imajiner
        return (Math.abs(reel - diger.reel)<EPS && Math.abs(imajiner - diger.imajiner)<EPS);
    }


    public void yazdir(){

        System.out.printf("%.1f + %.1fi \n", reel, imajiner);
    }
}

public class MyCircle {

    private MyPoint center;
    private int radius;

    public MyCircle(){
        center = new MyPoint();
        radius = 1;
    }

    public MyCircle(int x, int y, int radius){
        center = new MyPoint(x,y);
        setRadius(radius);
    }

    MyCircle(MyPoint center, int radius){
        this.center = new MyPoint();
        setCenter(center);
        this.radius = radius;
    }

    public void setRadius(int radius){
        if(radius <= 0){
            System.out.println("Wrong radius, set to 1");
            this.radius = 1;
        }else{
            this.radius = radius;
        }
    }

    public int getRadius(){
        return radius;
    }

    public void setCenter(MyPoint center){

        this.center.setXY(center.getX(), center.getY());
        // this.center = center;
    }

    public MyPoint getCenter() {
        return center;
    }

    public int getCenterX(){
        return center.getX();
    }

    public void setCenterX(int x){
        center.setX(x);
    }

    public int getCenterY(){
        return center.getY();
    }

    public void setCenterY(int y){
        center.setY(y);
    }

    public int[] getCenterXY(){
        return center.getXY();
    }

    public void setCenterXY(int x, int y){
        center.setXY(x,y);
    }

    public String toString() {
        return "MyCircle[radius = " + radius + ", center = "+ center + "]";
    }

    public double getArea(){
        return Math.PI * radius * radius;
    }

    public double getCircumference(){
        return 2 * Math.PI * radius;
    }

    public double distance(MyCircle another){
        return center.distance(another.getCenter());
    }
}

public class TestKarmasikSayi {

    public static void main(String[] args){

        KarmasikSayi sayi1 = new KarmasikSayi(3, 4);

        KarmasikSayi sayi2 = new KarmasikSayi(-2, 10);

        KarmasikSayi toplam = sayi1.topla(sayi2);

        KarmasikSayi carpim = sayi1.carp(sayi2);

        System.out.print("Sayi1: ");
        sayi1.yazdir();

        System.out.print("Sayi2: ");
        sayi2.yazdir();

        System.out.print("Toplam: ");
        toplam.yazdir();

        System.out.print("Carpim: ");
        carpim.yazdir();

        if(sayi1.esitmi(sayi2))
            System.out.println("Sayi1 sayi2'ye eşit");
        else
            System.out.println("Sayi1 sayi2'ye eşit değil");

    }
}

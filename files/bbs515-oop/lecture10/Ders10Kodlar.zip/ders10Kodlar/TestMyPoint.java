public class TestMyPoint {
    public static void main(String[] args){
        MyPoint myPoint1 = new MyPoint(2, 5);
        MyPoint myPoint2 = new MyPoint(1, 3);

        System.out.println(myPoint1);
        System.out.println(myPoint2);

        double d = myPoint1.distance(myPoint2);
        System.out.println("Distance between myPoint1 and myPoint2: "+d);

        double distToOrigin = myPoint1.distance();
        System.out.println("Distance of myPoint1 to origin: "+distToOrigin);

        double dist2 = myPoint1.distance(4, 7);
        System.out.println("Distance of myPoint1 to (4,7): "+dist2);

        int[] xyOfPoint1 = myPoint1.getXY();

        MyCircle myCircle1 = new MyCircle(1, 2, 3);
        System.out.println(myCircle1);

        MyCircle myCircle2 = new MyCircle(myPoint1, 4);
        System.out.println(myCircle2);
        myPoint1.setXY(0,0);
        System.out.println(myCircle2);

        MyPoint vertex1 = new MyPoint(0,0);
        MyPoint vertex2 = new MyPoint(4,0);
        MyPoint vertex3 = new MyPoint(0,4);

        MyTriangle myTriangle = new MyTriangle(vertex1, vertex2, vertex3);
        System.out.println(myTriangle);
        System.out.println(myTriangle.getType());
    }
}

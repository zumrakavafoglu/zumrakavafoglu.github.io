package package2;

public class TestPoints {

    public static void main(String[] args) {

        Point2D origin = new Point2D();
        System.out.println(origin);

        Point3D origin3D = new Point3D();
        System.out.println(origin3D);

        Point3D point = new Point3D(1,2,3);
        System.out.println(point);
    }

}

package package5;

public class MyCalendar {

    int year;

    int firstDayOfTheYear;

    String[][] days = new String[12][];

    static String[] weekDays = {"Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"};

    static String[] months = {"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};

    MyCalendar(int _year, int _firstDayOfTheYear){
        year = _year;
        firstDayOfTheYear = _firstDayOfTheYear;
    }

    void constructDays(){

        for(int i=0; i<days.length; i++){

            if(i == 1){
                if(isLeapYear())
                    days[i] = new String[29];
                else
                    days[i] = new String[28];
            }

            else if((i <= 6 && i % 2 == 0) || (i >= 7 && i%2 == 1)){
                days[i] = new String[31];
            }
            else{
                days[i] = new String[30];
            }
        }


        int counter = 0;
        for(int i=0; i<days.length; i++){
            for(int j=0; j<days[i].length; j++){
                days[i][j] = weekDays[(firstDayOfTheYear + counter)%7];
                counter ++;
            }
        }
    }

    boolean isLeapYear(){
        if((year % 4 == 0 && year % 100 !=0) || year % 400 == 0)
            return true;
        return false;
    }

    void printCalendar(){


        for(int i=0; i<days.length; i++){

            System.out.print(months[i]+"("+days[i].length+"): ");

            for(int j=0; j<days[i].length; j++){
                System.out.print(days[i][j]+" ");
            }
            System.out.println();
            System.out.println();
        }
    }


}

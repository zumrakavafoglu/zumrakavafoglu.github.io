package package5;

public class TestCalendar {

    public static void main(String[] args){
        MyCalendar myCalendar = new MyCalendar(2007,4);

        myCalendar.constructDays();
        myCalendar.printCalendar();

        System.out.println(findDayInCalendar(myCalendar, 2, 6));
    }

    public static String findDayInCalendar(MyCalendar myCalendar, int month, int day){
        return myCalendar.days[month-1][day-1];
    }
}

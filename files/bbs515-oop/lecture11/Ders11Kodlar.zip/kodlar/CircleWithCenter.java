

public class CircleWithCenter extends Circle implements IMovable, IComparable{

    double centerX, centerY;

    public CircleWithCenter(){
        this(1,0,0);
    }

    public CircleWithCenter(double radius, double centerX, double centerY){

        super(radius);
        this.centerX = centerX;
        this.centerY = centerY;
    }

    @Override
    public int compareTo(Object o) {
        if(getRadius()>((Circle)o).getRadius())
            return 1;
        else if (getRadius()<((Circle)o).getRadius())
            return -1;
        else
            return 0;
    }

    @Override
    public void moveLeft() {
        centerX -= stepSize;
    }

    @Override
    public void moveRight() {
        centerX += stepSize;
    }

    @Override
    public void moveUp() {
        centerY += stepSize;
    }

    @Override
    public void moveDown() {
        centerY -= stepSize;
    }
}

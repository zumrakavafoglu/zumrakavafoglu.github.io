
public class ComparableCircle extends Circle implements IComparable{

	public ComparableCircle(double radius) {
		super(radius);
	}
	
	@Override
	public int compareTo(Object o) {
		if (o instanceof ComparableCircle){
			if (getRadius() > ((ComparableCircle) o).getRadius())
				return 1;
			else if (getRadius() < ((ComparableCircle) o).getRadius())
				return -1;
			else return 0;
		}
		else
			return 0;
	}

}

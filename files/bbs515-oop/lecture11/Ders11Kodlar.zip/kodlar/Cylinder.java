
public class Cylinder extends Circle {

	protected double height;
	
	public Cylinder()
	{
		super();
		height = 1.0;
	}
	
	public Cylinder(double radius, double height)
	{

		this(radius,"white",height);
	}
	
	public Cylinder(double radius, String color, double height)
	{
		super(radius,color);
		this.height=height;
	}
	
	public double getHeight()
	{
		return height;
	}
	
	public void setHeight(double height) {
		this.height = height;
	}

	public double findArea()
	{
		return 2*super.findArea()+(2*getRadius()*Math.PI)*height;
	}
	
	public double findVolume()
	{
		return super.findArea()*height;
	}
	
	public String toString()
	{
		return "[Cylinder] radius = " + radius + " height = "+height+" color = "+color;
	}
}

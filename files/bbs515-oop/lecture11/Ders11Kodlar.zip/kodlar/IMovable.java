public interface IMovable {

    public final double stepSize = 1;

    public void moveLeft();
    public void moveRight();
    public void moveUp();
    public void moveDown();

}


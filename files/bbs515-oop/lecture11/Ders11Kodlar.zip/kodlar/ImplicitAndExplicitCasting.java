public class ImplicitAndExplicitCasting {

    public static void main(String[] args) {

        GeometricObject geometricObject1 = new Circle(2, "red");

        System.out.printf("Area of geometric object 1 is %.2f \n",
                geometricObject1.findArea());

        System.out.printf("Radius of geometric object 1 is %.2f \n",
                ((Circle)geometricObject1).getRadius());
    }
}

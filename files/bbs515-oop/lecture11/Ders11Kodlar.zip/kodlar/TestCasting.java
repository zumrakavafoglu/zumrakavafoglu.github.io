
public class TestCasting {

	public static void main(String[] args) {

		GeometricObject geo1 = new Circle(5);
		GeometricObject geo2 = new Cylinder(5,3);
		
		displayGeometricObject(geo1);
		displayGeometricObject(geo2);

	}

	static void displayGeometricObject(GeometricObject object)
	{
		System.out.println();
		System.out.println(object);
		
		System.out.println("The area is "+object.findArea());
		if(object instanceof Cylinder)
		{
			System.out.println("The volume is "+((Cylinder)object).findVolume());
		}
		
		else if(object instanceof Circle)
		{
			System.out.println("The perimeter is "+object.findPerimeter());
		}
	}
}

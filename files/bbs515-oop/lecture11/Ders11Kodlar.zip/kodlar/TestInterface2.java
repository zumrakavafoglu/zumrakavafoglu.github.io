
public class TestInterface2 {

	public static void main(String[] args) {

		CircleWithCenter circle1 = new CircleWithCenter(5, 1, 1);
        CircleWithCenter circle2 = new CircleWithCenter(4, 2, 2);
		
		IComparable circle = Max.max(circle1, circle2);
		System.out.println("The max circle's radius is " + ((Circle)circle).getRadius());
		System.out.println(circle);

		CylinderWithCenter cylinder1 = new CylinderWithCenter(5, 2 , 3, 3);
        CylinderWithCenter cylinder2 = new CylinderWithCenter(4, 5, 4, 4);
		
		IComparable cylinder = Max.max(cylinder1, cylinder2);

		System.out.println("\ncylinder1's volume is "+cylinder1.findVolume());
		System.out.println("cylinder2's volume is "+cylinder2.findVolume());
		System.out.println("The max cylinder's \tradius is "
				+ ((Cylinder)cylinder).getRadius()
				+ "\n\t\t\theight is "+((Cylinder)cylinder).getHeight()
				+ "\n\t\t\tvolume is "+((Cylinder)cylinder).findVolume());
		System.out.println(cylinder);

		Point point1 = new Point(1,2);
		Point point2 = new Point();

		IMovable[] movables = {circle1, circle2, point1, point2};

        for (IMovable movable: movables) {
            movable.moveDown();
        }
    }
}

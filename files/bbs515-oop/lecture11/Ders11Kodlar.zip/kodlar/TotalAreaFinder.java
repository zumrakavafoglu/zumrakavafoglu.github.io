
//Bir uygulamadaki tüm geometrik nesnelerin alanlarının toplamını bulalım.

public class TotalAreaFinder {

    public static void main(String[] args){

        Circle myCircle = new Circle(4, "green");
        Rectangle myRectangle = new Rectangle(3,5,"blue");
        Cylinder myCylinder = new Cylinder(7,"red",2);


        double totalArea = 0;
        totalArea += myCircle.findArea();
        totalArea += myRectangle.findArea();
        totalArea += myCylinder.findArea();

        System.out.printf("Total area of the objects in the scene is %.2f",
                totalArea);

    }
}


public class Circle extends GeometricObject implements IComparable{

	protected double radius;
	
	public Circle()
	{

		this(1.0,"white");
	}
	
	public Circle(double radius)
	{
		super();
		this.radius = radius;
	}
	
	public Circle(double radius, String color)
	{
		super(color);
		this.radius = radius;
	}
	
	public double getRadius()
	{
		return radius;
	}
	
	public void setRadius(double radius)
	{
		this.radius = radius;
	}
	
	public double findArea() {
		return radius*radius*Math.PI;
	}

	public double findPerimeter() {
		return 2*radius*Math.PI;
	}

	public String toString() {
		return "[Circle] radius = "+radius+" color = "+color;
	}

	@Override
	public int compareTo(Object o) {

		if (getRadius() > ((Circle) o).getRadius())
			return 1;
		else if (getRadius() < ((Circle) o).getRadius())
			return -1;
		else return 0;
	}
}

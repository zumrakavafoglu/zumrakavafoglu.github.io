public class ComparableTest1 {

    public static void main(String[] args){

        Circle c1 = new Circle(3.0);

        Rectangle r1 = new Rectangle(2,3);

        System.out.print(c1.compareTo(r1));

    }
}

public interface GenericComparable <T> {

    public int compareTo(T other);

}

import java.util.Scanner;

public class MyMapTest {

    public static void main(String[] args){

        MyMap<Long, Person> personMap = new MyMap<Long, Person>();

        personMap.put(64783912567L, new Person("Ayse", "Demir"));
        personMap.put(19832166541L, new Person("Hale", "Berber"));
        personMap.put(988786654332L, new Person("Kemal", "Ark"));
        personMap.put(901231234516L, new Person("Fatma", "Kale"));

        System.out.println("Enter the citizen id number: ");
        Scanner input = new Scanner(System.in);

        Long idNumber = input.nextLong();

        if(personMap.containsKey(idNumber)){
            System.out.println("Citizen with id " + idNumber + " is " + personMap.get(idNumber));
        }else{
            System.out.println("No citizen with id " + idNumber);
        }
    }

}

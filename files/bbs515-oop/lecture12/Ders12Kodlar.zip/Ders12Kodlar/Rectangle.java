
public class Rectangle extends GeometricObject {

	protected double width;
	protected double height;
	
	public Rectangle() {
		this(1.0,1.0,"white");
	}

	public Rectangle(double width, double height) {
		this.width = width;
		this.height = height;
	}
	
	public Rectangle(double width, double height, String color)
	{
		super(color);
		this.width = width;
		this.height = height;
	}

	
	public double getWidth() {
		return width;
	}

	public void setWidth(double width) {
		this.width = width;
	}

	public double getHeight() {
		return height;
	}

	public void setHeight(double height) {
		this.height = height;
	}

	@Override
	public double findArea() {
		return width*height;
	}

	@Override
	public double findPerimeter() {
		return 2*(width+height);
	}
	
	public String toString()
	{
		return "[Rectangle] width = "+width+" height = "+height+" color = "+color;
	}

}

public class StackTest
{
    public static void main(String[] args){

        double[] doubleElements = {1.1, 2.2, 3.3, 4.4, 5.5, 6.6};
        int[] integerElements = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11};

        Stack<Double> doubleStack; // stack stores Double objects
        Stack<Integer> integerStack; // stack stores Integer objects

        doubleStack = new Stack<Double>(5); // Stack of Doubles

        integerStack = new Stack<Integer>(10); // Stack of Integers

        pushDoubleArray(doubleStack,doubleElements);
        pushIntegerArray(integerStack,integerElements);

    }

    public static void pushDoubleArray( Stack<Double> stack, double[] elements){

        for(double element : elements){
            System.out.println("Element to push: " + element);
            stack.push(element);
        }
    }

    public static void pushIntegerArray( Stack<Integer> stack, int[] elements){

        for(int element : elements){
            System.out.println("Element to push: " + element);
            stack.push(element);
        }
    }

}
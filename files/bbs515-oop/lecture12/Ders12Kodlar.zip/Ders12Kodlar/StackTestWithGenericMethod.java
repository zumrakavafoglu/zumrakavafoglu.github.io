public class StackTestWithGenericMethod {

    public static void main(String[] args){

        Double[] doubleElements = {1.1, 2.2, 3.3, 4.4, 5.5, 6.6};
        Integer[] integerElements = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11};

        Stack<Double> doubleStack; // stack stores Double objects
        Stack<Integer> integerStack; // stack stores Integer objects

        doubleStack = new Stack<Double>(5); // Stack of Doubles

        integerStack = new Stack<Integer>(10); // Stack of Integers

        pushArray(doubleStack,doubleElements);
        pushArray(integerStack,integerElements);

    }

    public static <T> void pushArray( Stack<T> stack, T[] elements){

        for(T element : elements){
            System.out.println("Element to push: " + element);
            stack.push(element);
        }
    }

}

public class TestEquality1 {

    public static void main(String[] args){

        Address address1 = new Address(13, "Sumak Sk.", "Ankara", "Turkiye");
        Address address2 = new Address(13, "Sumak Sk.", "Ankara", "Turkiye");

        System.out.println("Adress1: "+address1);
        System.out.println("Adress2: "+address2);

        if(address1.equals(address2))
            System.out.println("Adress1 is same with address2");
        else
            System.out.println("Adress2 is not same with address2");

    }
}

public class ExceptionExample {

    public static void main(String[] args){

        int number1 = 0;

        int number2 = 3;

        int number3 = number2 / number1;

        System.out.println("Result: " + number3);

    }
}

import java.util.Scanner;

public class MultipleCatchExample {

    public static void main(String[] args){

        int arr[] = new int[10];

        int number = 5;

        Scanner input = new Scanner(System.in);

        try{

           System.out.println("Enter the divisor: ");

           int divisor = input.nextInt();

           number = number / divisor;

           System.out.println("Enter the array index: ");

           int i = input.nextInt();

           arr[i] = number;
        }
        catch (ArithmeticException e){
            System.out.println("Division by zero is wrong!");
        }
        catch (Exception e){
            System.out.println("Array index is out of bounds!");
        }

        System.out.println("Code must go on!");
    }
}

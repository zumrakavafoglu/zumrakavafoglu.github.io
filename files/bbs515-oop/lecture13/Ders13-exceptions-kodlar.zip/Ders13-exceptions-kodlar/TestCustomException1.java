import java.util.Scanner;

class TestCustomException1{

    public static void main(String args[]){

        System.out.print("Enter your age: ");

        Scanner input = new Scanner(System.in);

        int age = input.nextInt();

        try{
            if(age < 18)
            throw new InvalidAgeException("age not valid, must be >= 18");
        }
        catch(Exception m)
        {
            m.printStackTrace();
        }

        System.out.println("rest of the code...");
    }
}
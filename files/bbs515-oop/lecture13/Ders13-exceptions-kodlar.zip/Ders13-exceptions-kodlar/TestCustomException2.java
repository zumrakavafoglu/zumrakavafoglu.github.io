import java.util.Scanner;

class TestCustomException2{

    public static void main(String args[]) throws InvalidAgeException{

        System.out.print("Enter your age: ");

        Scanner input = new Scanner(System.in);

        int age = input.nextInt();


        if(age < 18)
            throw new InvalidAgeException("age not valid, must be >= 18");

        System.out.println("rest of the code...");
    }
}
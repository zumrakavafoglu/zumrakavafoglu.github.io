import java.util.Scanner;

public class TestCustomException3 {

    public static void validate(int age) throws InvalidAgeException{
        if(age < 18)
            throw new InvalidAgeException("age not valid, must be >= 18");
        else
            System.out.println("Welcome to vote!");
    }

    public static void main(String args[]){

        System.out.print("Enter your age: ");

        Scanner input = new Scanner(System.in);

        int age = input.nextInt();

        try{
            validate(age);
        }
        catch(InvalidAgeException e){
            System.out.println(e);
        }

        System.out.println("rest of the code...");
    }
}

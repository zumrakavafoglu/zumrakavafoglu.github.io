import java.util.Scanner;

public class ThrowingExample {

    public static void main(String[] args){

        System.out.print("Give me an integer: ");
        Scanner input = new Scanner(System.in);
        int number = input.nextInt();
        try{
            if(number < 0)
                throw new RuntimeException();
            System.out.println("Thank you");
        }catch(Exception e){
            System.out.println("Number is less than zero");
            throw  e;
        }
    }
}

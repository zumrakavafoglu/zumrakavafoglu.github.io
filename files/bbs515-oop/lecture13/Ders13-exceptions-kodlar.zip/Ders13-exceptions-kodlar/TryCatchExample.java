public class TryCatchExample {

    public static void main(String[] args){

        int number1 = 0, number2 = 0, number3 = 0;
        try {
             number1 = 0;

             number2 = 3;

             number3 = number2 / number1;

            System.out.println("Result: " + number3);

        } catch(NullPointerException e){
            System.out.println("Exception occured and handled ! ");

        }finally{
            System.out.println("finally");
        }

        System.out.print("bbcbckn");
    }
}

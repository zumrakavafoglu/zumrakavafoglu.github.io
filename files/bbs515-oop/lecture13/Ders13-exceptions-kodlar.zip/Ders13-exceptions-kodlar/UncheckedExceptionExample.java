import java.util.Scanner;

public class UncheckedExceptionExample {
    public static void main(String args[]){

        System.out.print("Enter your height: ");

        Scanner input = new Scanner(System.in);

        double height= input.nextDouble();

        if(height <= 0)
            throw new InvalidHeightException("height not valid, must be positive");

        System.out.println("rest of the code...");
    }
}

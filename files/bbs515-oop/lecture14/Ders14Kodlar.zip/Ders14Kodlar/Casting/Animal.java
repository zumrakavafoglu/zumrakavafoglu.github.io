package Casting;

public class Animal {

    public Animal(){
        System.out.println("An animal is created");
    }

    public Animal(int n){
        System.out.println("An animal is created with "+n);

    }

    public void move(){
        System.out.println("I am moving");
    }

    public void speak(){
        System.out.println("I am speaking");
    }
}

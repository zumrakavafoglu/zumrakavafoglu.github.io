package Casting;

public class Cat extends Animal {

    public Cat(){
        System.out.println("A cat is created");
    }

    public Cat(String name){
        super(3);
        System.out.println("A cat is created with name: "+name);

    }

    public void speak(){
        System.out.println("Miyav");
    }

    public void purr(){
        System.out.println("Purr");
    }
}

package Casting;

public class Dog extends Animal {

    public void speak(){
        System.out.println("Hav");
    }
}

package Maps;

import java.util.HashMap;

public class Anagram {

    public static boolean isAnagram(String str1, String str2){

        if(str1.length() != str2.length())
            return false;

        HashMap<Character, Integer> letterCountMap = new HashMap<Character, Integer>();

        int count;
        Character key;

        for(int i=0; i<str1.length(); i++){

            count = 0;
            key = str1.charAt(i);

            if(letterCountMap.containsKey(key)){
                count = letterCountMap.get(key);
            }

            letterCountMap.put(key,++count);
        }

        for(int i=0; i<str2.length(); i++){

            key = str2.charAt(i);

            if(!letterCountMap.containsKey(str2.charAt(i)))
                return false;

            if(letterCountMap.get(key) == 1)
                letterCountMap.remove(key);
            else
                letterCountMap.put(key,letterCountMap.get(key)-1);

        }

        return letterCountMap.isEmpty();
    }

    public static void main(String[] args){

        String str1 = "abcde";
        String str2 = "cdabe";

        if(isAnagram(str1, str2))
            System.out.println("Anagram");
        else
            System.out.println("Not Anagram");
    }

}

package Maps;

import java.util.HashMap;

public class Anagram2 {

    public static HashMap<Character, Integer> getLetterMap(String word){
        int count;
        Character key;

        HashMap<Character, Integer> map = new HashMap<>();

        for(int i=0; i<word.length(); i++){

            count = 0;
            key = word.charAt(i);

            if(map.containsKey(key)){
                count = map.get(key);
            }

            map.put(key,++count);
        }

        return map;
    }

    public static boolean areLetterMapsEqual(HashMap<Character, Integer> map1, HashMap<Character, Integer> map2){

        for(Character c: map1.keySet()){
            if(!map2.containsKey(c))
                return false;
            if(!map2.get(c).equals(map1.get(c)))
                return false;
        }

        return true;
    }

    public static boolean isAnagram(String str1, String str2){
        HashMap<Character, Integer> letterMap1 = getLetterMap(str1);
        HashMap<Character, Integer> letterMap2 = getLetterMap(str2);

        return areLetterMapsEqual(letterMap1, letterMap2);
    }

    public static void main(String[] args){
        String str1 = "abcde";
        String str2 = "cdabe";

        if(isAnagram(str1, str2))
            System.out.println("Anagram");
        else
            System.out.println("Not Anagram");
    }

}


package Maps;

//checked exception
public class InvalidTriangleException extends Exception {

    int side1, side2, side3;

    public InvalidTriangleException(String message,int side1, int side2, int side3)
    {
        super(message);
        this.side1 = side1;
        this.side2 = side2;
        this.side3 = side3;
    }

    @Override
    public String toString() {
        return super.toString() + "side1: " + side1
                + "side2: " + side2 + "side3: " + side3  ;
    }
}

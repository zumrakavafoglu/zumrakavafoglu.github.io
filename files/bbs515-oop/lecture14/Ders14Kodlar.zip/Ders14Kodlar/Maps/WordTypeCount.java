
    // Program counts the number of occurrences of each word in a string

package Maps;
import java.util.StringTokenizer;
import java.util.Map;
import java.util.HashMap;
import java.util.Set;
import java.util.TreeSet;

import java.util.Scanner;

    public class WordTypeCount {

        public static void main(String[] args){

            Map< String, Integer > map  = new HashMap< String, Integer >();

            createMap(map); // create map based on user input

            displayMap(map); // display map content

        }

    // create map from user input
    public static void createMap(Map<String, Integer> map) {

        Scanner scanner = new Scanner( System.in );

        System.out.println( "Enter a string:" ); // prompt for user input

        String input = scanner.nextLine();

        // create StringTokenizer for input
        StringTokenizer tokenizer = new StringTokenizer( input , " ,.:-_");

        // processing input text
        while ( tokenizer.hasMoreTokens() ) // while more input
        {
            String word = tokenizer.nextToken().toLowerCase(); // get word

            // if the map contains the word
            if (map.containsKey(word)) {
                int count = map.get(word); //get current count
                map.put(word, count + 1); // increment count by one
            } else {
                map.put(word, 1); // add new word with a count of 1 to map
            }
        }

    } // end method createMap


    // display map content
    public static void displayMap(Map<String, Integer> map) {
        // get keys
        Set< String > keys = map.keySet();

        // sort keys
        TreeSet< String > sortedKeys = new TreeSet< String >( keys );

        System.out.println( "Map contains:\nKey\t\t\t\tValue" );

        // generate output for each key in map
        for ( String key : sortedKeys )
            System.out.printf( "%-10s%10s\n", key, map.get( key ));

        System.out.printf("\nsize:%d\nisEmpty:%b\n", map.size(), map.isEmpty());
    } // end method displayMap

} // end class WordTypeCount

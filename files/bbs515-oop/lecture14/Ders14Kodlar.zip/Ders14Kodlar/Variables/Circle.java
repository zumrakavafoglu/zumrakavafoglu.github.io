package Variables;

public class Circle {

	private double radius;
	
	static int numberOfCircles;
	
	public Circle()
	{
		radius = 1.0;
		numberOfCircles++;
	}
		
	public Circle(double r)
	{
		radius = r;
		numberOfCircles++;
	}
	
	public double getRadius()
	{
		return radius;
	}
		
	public void setRadius(double newRadius)
	{
		radius = newRadius;
	}
	
	public double findArea()
	{
		return radius*radius*Math.PI;
	}
}

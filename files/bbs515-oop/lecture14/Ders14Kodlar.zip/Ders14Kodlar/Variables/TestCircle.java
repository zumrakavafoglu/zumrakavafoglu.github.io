package Variables;

public class TestCircle {

	public static void main(String[] args) {
		
		Circle c1 = new Circle();
		
		System.out.println("Number of circles created: "+ Circle.numberOfCircles );
		
		Circle c2 = new Circle(5);
		
		System.out.println("Number of circles created: "+Circle.numberOfCircles);
		
		Circle c3 = new Circle(3);
		
		System.out.println("Number of circles created: "+Circle.numberOfCircles);
	}
}

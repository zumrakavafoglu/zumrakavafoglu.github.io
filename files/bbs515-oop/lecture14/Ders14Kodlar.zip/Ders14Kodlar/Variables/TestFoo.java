package Variables;


public class TestFoo {

	public static void main(String[] args) {
		Foo f = new Foo();
		f.p();
	}
}

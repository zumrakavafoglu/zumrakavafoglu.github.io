
//Zumra Kavafoglu
//02.10.2017

//Program for displaying the sum of two integers
public class Addition {

    public static void main(String args[]) {

        //first integer to add
        int number1;

        //second integer to add
        int number2;

        //sum of two integers
        int sum;

        //assign number1
        number1 = 3;

        //assign number2
        number2 = 8;

        //Compute the sum
        sum = number1 + number2;

        //Print the sum
        System.out.printf("Sum of %d and %d is %d\n", number1, number2, number1 + number2);

    }
}
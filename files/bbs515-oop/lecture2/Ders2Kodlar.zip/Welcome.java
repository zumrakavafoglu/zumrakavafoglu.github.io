
//Zumra Kavafoglu
//02.10.2017

//Text-printing program
public class Welcome {

    //main method begins execution of Java application
    public static void main(String args[]) {

        System.out.println("Welcome to Java Programming");

    }//end method main
}//end class Welcome
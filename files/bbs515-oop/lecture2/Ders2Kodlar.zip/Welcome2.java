
//Zumra Kavafoglu
//02.10.2017

//Text-printing with multiple statements
public class Welcome2 {

    //main method begins execution of Java application
    public static void main(String args[]) {

        System.out.print("Welcome");
        System.out.println("to Java Programming");

    }//end method main
}//end class Welcome2
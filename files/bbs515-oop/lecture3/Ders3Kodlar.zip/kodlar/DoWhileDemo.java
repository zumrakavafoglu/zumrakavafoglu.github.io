//Zumra Kavafoglu
//09.10.2017
//Program for demanding an integer from the user until the input is negative

import java.util.Scanner;

public class DoWhileDemo {

    public static void main(String[] args) {

        int number;

        Scanner input = new Scanner(System.in);

        do {

            System.out.print("Input a positive number to continue, a negative number to stop: ");

            number =input.nextInt();

        } while(number>0);

    }
}

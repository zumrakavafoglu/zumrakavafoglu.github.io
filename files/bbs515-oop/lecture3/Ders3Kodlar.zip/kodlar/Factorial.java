
//Zumra Kavafoglu
//09.10.2017
//Program for calculating the factorial of a positive integer

import java.util.Scanner;

public class Factorial
{
	public static void main(String[] args)
	{
		int n;
		int n_factorial = 1;

		Scanner input = new Scanner(System.in);

		System.out.print("Input a non-negative integer : ");

		n = input.nextInt();
		
		while(n<0)
		{
			System.out.print("You should input a non-negative integer : ");
			n = input.nextInt();
		}

		if(n>0)
		{
			for(int count=1 ; count<=n ; count++)

				n_factorial *= count;
	    }

	    // if n is zero n_factorial will be 1, which is already its default value

	    System.out.printf("%d! = %d", n, n_factorial);
		
	}
}

//Zumra Kavafoglu
//09.10.2017
//Program for calculating the value of y = ln(1/(1-x)) for a given x


import java.util.Scanner;

public class LnFunction
{
	public static void main(String[] args)
	{
		double x ,y;

		final double EPS = 1.0E-14;

		Scanner input = new Scanner(System.in);

		System.out.print("Enter the x value : ");

		x = input.nextDouble();
		
		if(x<1.0)
		{
			y = Math.log( 1 / (1-x) );

		  	System.out.println("y(x) = " + y);
		}
		else if( Math.abs(x - 1.0) < EPS )

		  System.out.println("y(x) = infinity");

		else
			
		  System.out.println("Natural logarithm is defined only for positive values");
		
	}
}
import java.util.Scanner;

//Program for printing whether a student passed or failed the exam
public class StudentPassFailExam {

    public static void main(String[] args) {

        final double passingGrade = 55;

        double grade;

        Scanner input = new Scanner(System.in);

        System.out.println("Enter student's grade: ");

        grade = input.nextDouble();

        if(grade >= passingGrade){
            System.out.println("Passed");
        }else{
            System.out.println("Failed");
        }

        //Same statetment with conditional operator
        //System.out.println(grade >= passingGrade ? "Passed" : "Failed");

    }
}


//Zumra Kavafoglu
//09.10.2017
//Program for printing the day name according to the day number input by the user

import java.util.Scanner;

public class SwitchDays {

    public static void main(String[] args) {

        int dayNumber;
        String dayName = "";

        System.out.print("Enter the day number: ");
        Scanner input = new Scanner(System.in);
        dayNumber = input.nextInt();

       /* if(dayNumber == 1){
            dayName = "Monday";
        }else if(dayNumber == 2){
            dayName = "Tuesday";
        }else if(dayNumber == 3){
            dayName = "Wednesday";
        }else if(dayNumber == 4){
            dayName = "Thursday";
        }else if(dayNumber == 5){
            dayName = "Friday";
        }else if(dayNumber == 6){
            dayName = "Saturday";
        }else if(dayNumber == 7){
            dayName = "Sunday";
        }else{
            System.out.println("Wrong day number");
        }*/

        //with switch
         switch (dayNumber) {
            case 1:
                dayName = "Monday";
                break;
            case 2:
                dayName = "Tuesday";
                break;
             case 3:
                dayName = "Wednesday";
                break;
            case 4:
                dayName = "Thursday";
                break;
            case 5:
                dayName = "Friday";
                break;
            case 6:
                dayName = "Saturday";
                break;
            case 7:
                dayName = "Sunday";
                break;
            default:
                System.out.println("You entered wrong number");
                break;
        }

        System.out.println(dayName);

    }
}


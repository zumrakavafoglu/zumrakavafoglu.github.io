
//Zumra Kavafoglu
//09.10.2017
//Program for printing integers from 1 to 10

public class WhileDemo {

    public static void main(String[] args){

        int count = 1;

        while (count < 11) {

            System.out.println("Count is: " + count);

            count++;
        }

    }
}


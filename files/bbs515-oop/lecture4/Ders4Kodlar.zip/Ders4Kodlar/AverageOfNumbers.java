public class AverageOfNumbers {

    public static void main(String args[]) {

        int firstNumber;
        int lastNumber;

        double sum = 0;
        double average = 0;

        firstNumber = 2;
        lastNumber = 11;

        for(int i=firstNumber; i<=lastNumber; i++){
            sum += i;
        }

        average = sum / (lastNumber-firstNumber+1);

        System.out.printf("\nAverage of integers between %d and %d is %.2f", firstNumber, lastNumber, average);


        firstNumber = 18;
        lastNumber = 43;

        for(int i=firstNumber; i<=lastNumber; i++){
            sum += i;
        }

        average = sum / (lastNumber-firstNumber+1);

        System.out.printf("\nAverage of integers between %d and %d is %.2f", firstNumber, lastNumber, average);


        firstNumber = 113;
        lastNumber = 157;

        for(int i=firstNumber; i<=lastNumber; i++){
            sum += i;
        }

        average = sum / (lastNumber-firstNumber+1);

        System.out.printf("\nAverage of integers between %d and %d is %.2f", firstNumber, lastNumber, average);


    }
}

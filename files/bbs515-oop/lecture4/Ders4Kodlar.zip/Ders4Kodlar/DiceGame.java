import java.util.Scanner;

public class DiceGame {

    public static int rollTheDice(){
        double rand = Math.random();

        int diceNumber = (int)(6 * rand + 1);

        return diceNumber;
    }

    public static void main(String args[]){

        int dice1;

        int dice2;

        Scanner input = new Scanner(System.in);

        System.out.println("First player! Press 1 to roll the dice!");

        if(input.nextInt() == 1){

            dice1 = rollTheDice();

            System.out.println("Your dice is: " + dice1);

            System.out.println("Second player! Press 2 to roll the dice!");

            if(input.nextInt() == 2){

                dice2 = rollTheDice();

                System.out.println("Your dice is: " + dice2);

                if(dice1 > dice2){
                    System.out.println("First player wins!!");
                }else if(dice2 > dice1){
                    System.out.println("Second player wins!!");
                }else{
                    System.out.println("Draw!");
                }

            }

        }

    }
}

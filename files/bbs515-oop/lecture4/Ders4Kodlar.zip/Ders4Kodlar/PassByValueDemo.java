public class PassByValueDemo {

    public static void incrementValues(int number1, int number2){

        number1 ++;
        number2 ++;

        System.out.println("local number1: " + number1);
        System.out.println("local number2: " + number2);

    }

    public static void main(String args[]){

        int number1 = 3;
        int number2 = 4;

        System.out.println("Before calling IncrementValues ");

        System.out.println("number1: " + number1);
        System.out.println("number2: " + number2);

        System.out.println("---------------------------");

        incrementValues(number1,number2);

        System.out.println("---------------------------");

        System.out.println("After calling IncrementValues ");
        System.out.println("number1: " + number1);
        System.out.println("number2: " + number2);

    }

}

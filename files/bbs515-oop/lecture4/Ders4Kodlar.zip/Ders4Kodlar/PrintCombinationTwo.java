import java.util.Scanner;

public class PrintCombinationTwo {

    public static void combinationTwo(int n){

        System.out.printf("1'den %d'e kadar tüm ikili kombinasyonlar: \n", n);

        int combinationCounter = 0;

        for(int i=1; i<n; i++){
            for(int j = i+1; j<=n; j++){
                System.out.printf("( %d - %d )\n",i,j);
                combinationCounter ++;
            }
        }

        System.out.print("Kombinasyon sayısı: "+combinationCounter);
    }

    public static void main(String args[]){

        System.out.print("Hangi sayıya kadar kombinasyon hesaplanacak?: ");

        Scanner input = new Scanner(System.in);

        int n = input.nextInt();

        combinationTwo(n);
    }
}

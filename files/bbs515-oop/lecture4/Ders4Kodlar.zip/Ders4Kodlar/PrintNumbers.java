public class PrintNumbers {

    public static void main(String args[]){

        int firstNumber;
        int lastNumber;

        firstNumber = 1;
        lastNumber = 7;

        System.out.printf("\nNumbers from %d to %d are : ",firstNumber, lastNumber);

        for(int i=firstNumber; i<=lastNumber; i++){
            System.out.print(i + " ");
        }

        firstNumber = 15;
        lastNumber = 29;

        System.out.printf("\nNumbers from %d to %d are : ",firstNumber, lastNumber);

        for(int i=firstNumber; i<=lastNumber; i++){
            System.out.print(i + " ");
        }


        firstNumber = 103;
        lastNumber = 147;

        System.out.printf("\nNumbers from %d to %d are : ",firstNumber, lastNumber);

        for(int i=firstNumber; i<=lastNumber; i++){
            System.out.print(i + " ");
        }

    }
}

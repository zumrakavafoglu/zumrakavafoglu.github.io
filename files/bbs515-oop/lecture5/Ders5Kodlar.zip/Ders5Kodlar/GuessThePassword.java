import java.util.Scanner;

public class GuessThePassword {

    public static void shuffleElements(int arr[]){
        int n = arr.length;
        int randomIndex;

        for(int i=0; i<n; i++){

            //Generate a random index
            randomIndex = (int)(n*Math.random());

            //swap element at i with element at randomIndex

            swapElements(arr, i, randomIndex);
        }
    }

    public static void main(String[] args){

        int[] password = {8,4,5,2,3};

        int n = password.length;

        int[] shuffledPassword = new int[n];

        System.arraycopy(password,0,shuffledPassword,0,n);

        shuffleElements(shuffledPassword);

        System.out.println("The shuffled password is: ");
        printArray(shuffledPassword);

        System.out.print("Guess the password(Enter each digit separately): ");

        Scanner input = new Scanner(System.in);

        int guessedDigit;
        boolean guess = true;

        //Kullanıcı bütün değerleri girdikten sonra döngüden çıkmak istiyorsak
        for(int value:password){
            guessedDigit = input.nextInt();

            //Because of the & operator,  guess remains true if (value== guessedDigit) is true at each loop step
            //if(value==guessedDigit) is false once, guess will be false

            guess = guess & (value == guessedDigit);
        }

        //Kullanıcının ilk girdiği hatalı değerde döngüden çıkmak istiyorsak
        /*for(int value:password){
            guessedDigit = input.nextInt();
            if(guessedDigit != value) {
                guess = false;
                break;
            }
        }*/

        if(guess)
            System.out.print("Congrats! True Guess");
        else
            System.out.print("Sorry! Wrong Guess");

    }


    public static void swapElements(int[] arr1, int index1, int index2){

        int temp = arr1[index1];
        arr1[index1] = arr1[index2];
        arr1[index2] = temp;
    }

    public static void printArray(int[] arr){

        int n = arr.length;

        for(int i=0; i<n; i++)
            System.out.print(arr[i] + " ");

        System.out.print('\n');
    }
}

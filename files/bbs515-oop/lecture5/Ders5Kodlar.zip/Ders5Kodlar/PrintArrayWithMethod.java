public class PrintArrayWithMethod {

    public static void printArray(int[] arr){

        int n = arr.length;

        for(int i=0; i<n; i++)
            System.out.print(arr[i] + " ");
    }

    public static void main(String[] args){

        int[] oddNumbers = {1,3,5,7,9};

        printArray(oddNumbers);
    }

}

public class PrintLetterArray {

    public static void main(String[] args){

        char[] letterArray = {'p', 't', 'q', 's', 'z'};

        int numOfLetters = letterArray.length;

        for(int i=0; i<numOfLetters; i++){
            System.out.println(letterArray[i]);
        }
    }
}

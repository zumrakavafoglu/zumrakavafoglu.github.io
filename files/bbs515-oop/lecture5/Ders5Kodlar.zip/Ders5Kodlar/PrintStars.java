import java.util.Scanner;

public class PrintStars {
    public static void main(String[] args){

        int height;

        Scanner input = new Scanner(System.in);

        System.out.print("Input height: ");

        height = input.nextInt();

        for(int i=0; i<height; i++){
            for(int j=0; j<i+1; j++){
                System.out.print("*");
            }
            System.out.println();
        }

        for(int i=height-1; i>=0; i--){
            for(int j=0; j<i; j++){
                System.out.print("*");
            }
            System.out.println();
        }
    }
}


public class SimpleArray {

    public static void printArray(int[] arr){

        int n = arr.length;

        for(int i=0; i<n; i++)
            System.out.print(arr[i] + " ");
    }

    public static void main(String[] args){

        int[] arr = new int[3];

        arr[0] = 3;
        arr[1] = 5;
        arr[2] = 7;

        for(int i=0; i<5; i++){
            arr[i] = i + 1;
        }

    }
}

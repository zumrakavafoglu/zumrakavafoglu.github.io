public class SumArray {
    public static void main(String[] args){

        double[] numberArray = {1.7, 2.3, 8.6, 9.0, 0.45, 3.9};

        double sum = 0;

        int arrayLength = numberArray.length;

        for(int i=0; i<arrayLength; i++){
            sum += numberArray[i];
        }

        System.out.printf("Sum of numbers in the array is: %.2f", sum);
    }
}

public class SwapDemo {

    public static void printArray(int[] arr){

        int n = arr.length;

        for(int i=0; i<n; i++)
            System.out.print(arr[i] + " ");

        System.out.println();
    }

    public static void swapElements(int[] arr1, int index1, int index2){

        int temp = arr1[index1];
        arr1[index1] = arr1[index2];
        arr1[index2] = temp;
    }


    public static void main(String args[]){
        int[] intArray = {1, 3, 5, 7, 9};

        System.out.println("Array before swapping");
        printArray(intArray);

        swapElements(intArray, 0, 3);

        System.out.println("Array after swapping");
        printArray(intArray);
    }
}

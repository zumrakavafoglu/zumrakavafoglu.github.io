public class TestCopyArray {
    public static void printArray(int[] arr){

        int n = arr.length;

        for(int i=0; i<n; i++)
            System.out.print(arr[i] + " ");
    }

    public static void main(String[] args){

        int[] array1 = {1, 2, 3};

        int[] array2 = {7, 8, 9};

        array2 = array1;

        System.out.println("Before modifying array1: ");

        System.out.print("Elements of array1: ");
        printArray(array1);

        System.out.print("\nElements of array2: ");
        printArray(array2);

        //Modify array 1
        for(int i=0; i<array1.length; i++){
            array1[i] = 0;
        }

        System.out.println("\n\nAfter modifying array1: ");

        System.out.print("Elements of array1: ");
        printArray(array1);

        System.out.print("\nElements of array2: ");
        printArray(array2);

    }
}

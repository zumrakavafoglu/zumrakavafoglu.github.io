import java.util.Scanner;

public class TriangleType {
    public static void main(String[] args){

        int side1;
        int side2;
        int side3;

        Scanner input = new Scanner(System.in);

        System.out.print("Input the first side: ");
        side1 = input.nextInt();

        System.out.print("Input the second side: ");
        side2 = input.nextInt();

        System.out.print("Input the third side: ");
        side3 = input.nextInt();

        if(Math.abs(side1-side2)>=side3 || side3 >= side1+side2 ||
                Math.abs(side2-side3)>=side1 || side1 >= side2+side3
                || Math.abs(side1-side3)>=side2 || side2 >= side1+side3 ){
            System.out.print("Not a triangle");
        }else if(side1 == side2 && side1 == side3){
            System.out.print("It's an equilateral triangle");
        }else if(side1 == side2 || side1 == side3 || side2 == side3)
            System.out.print("It's an isosceles triangle");
        else
            System.out.print("It's a scalene triangle");

    }
}

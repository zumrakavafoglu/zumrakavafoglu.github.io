public class PascalTriangle {
    public static void main(String[] args){

        int height = 10;

        int pascalTri[][] = new int[height][];

        for(int i=0; i<height; i++){
            pascalTri[i] = new int[i+1];
        }

        pascalTri[0][0] = 1;

        for(int i=1; i<height; i++){
            for(int j=0; j<pascalTri[i].length; j++){
                if(j==0 || j==pascalTri[i].length-1)
                    pascalTri[i][j] = 1;
                else{
                    pascalTri[i][j] = pascalTri[i-1][j-1] + pascalTri[i-1][j];
                }
            }
        }

        printPascalTriangle(pascalTri);
    }

    public static void printPascalTriangle(int[][] pascalTri){

        int triangleHeight = pascalTri.length;
        for(int i=0; i<triangleHeight; i++){
            for(int j=0; j<triangleHeight-i-1; j++){
                System.out.print("\t");
            }
            for(int j=0; j<pascalTri[i].length; j++){
                System.out.print(pascalTri[i][j]+"\t\t");
            }
            System.out.println();
        }
    }
}

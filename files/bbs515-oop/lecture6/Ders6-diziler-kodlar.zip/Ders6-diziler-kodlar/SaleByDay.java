import java.util.Scanner;

public class SaleByDay {

    public static int columnSum(int[][] arr, int columnIndex){

        int rowSize = arr.length;

        int total = 0;

        for(int i=0; i<rowSize; i++){
            total += arr[i][columnIndex];
        }
        return total;
    }

    public static void main(String[] args) {

        int[][] sales = {{15, 7, 3, 0, 12, 10, 4},
                {3, 8, 7, 6, 1, 11, 2},
                {1, 17, 3, 9, 10, 1, 1},
                {2, 6, 7, 5, 18, 25, 20}};


        int dailySale;
        int day;
        Scanner input = new Scanner(System.in);

        System.out.print("Enter the day number(1-7): ");
        day = input.nextInt();

        dailySale = columnSum(sales,day-1);

        System.out.printf("Total sale on day %d is %d: ", day, dailySale);

    }
}

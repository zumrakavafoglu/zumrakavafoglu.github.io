public class TotalSale {

    public static int sum(int[][] arr){
        int rowSize = arr.length;

        int columnSize = arr[0].length;

        int total = 0;

        for(int i=0; i<rowSize; i++){
            for(int j=0; j<columnSize; j++){
                total += arr[i][j];
            }
        }

        return total;
    }

    public static void main(String[] args) {

        int[][] sales = {{15, 7, 3, 0, 12, 10, 4},
                {3, 8, 7, 6, 1, 11, 2},
                {1, 17, 3, 9, 10, 1, 1},
                {2, 6, 7, 5, 18, 25, 20}};

        int totalSale = sum(sales);

        System.out.print("Total sale this week: "+ totalSale);
    }
}


public class Circle {

	public double radius;
	
	public Circle()
	{
		radius = 1.0;
	}
		
	public Circle(double r)
	{
		radius = r;
	}
	
	public double findArea()
	{
		return radius*radius*Math.PI;
	}
}

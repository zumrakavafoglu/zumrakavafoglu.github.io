public class Rectangle {

    public double width;
    public double height;

    public Rectangle(){
        width = 1;
        height =1;
    }

    public Rectangle(double _width, double _height){
        width = _width;
        height = _height;
    }

    public double findArea(){
        return width*height;
    }

    public double findPerimeter(){
        return 2*(width + height);
    }
}


public class TestCircle {

	public static void main(String[] args) {

		Circle circle1 = new Circle(7);
		
		double radius1 = circle1.radius;
		
		System.out.println("Radius of first circle is: "+radius1);
		
		double area1 = circle1.findArea();
		
		System.out.println("Area of first circle is: "+area1);
		
		Circle circle2 = new Circle();
		
		double radius2 = circle2.radius;
		
		System.out.println("Radius of second circle is: "+radius2);
		
		double area2 = circle2.findArea();
		
		System.out.println("Area of second circle is: "+area2);

	}
}

public class TestRectangle {
    public static void main(String[] args){
        Rectangle rectangle1 = new Rectangle(3,7);
        double area1 = rectangle1.findArea();
        System.out.println("Area of rectangle1: "+area1);
    }
}

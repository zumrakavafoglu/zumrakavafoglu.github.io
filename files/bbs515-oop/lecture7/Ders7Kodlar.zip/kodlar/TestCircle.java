

public class TestCircle {
    public static void main(String[] args){

        //Create a circle with radius 5.0
        Circle myCircle = new Circle(5.0);
        System.out.println("The area of the circle with radius " + myCircle.getRadius()+" is " + myCircle.findArea());

        //Increase myCircle's radius by 10%
        myCircle.setRadius(myCircle.getRadius()*1.1);
        System.out.println("The area of the circle with radius " + myCircle.getRadius()+" is " + myCircle.findArea());

        //Try to assign a negative value to the circle radius, setRadius method would avoid this
        myCircle.setRadius(-1);
        System.out.println("The area of the circle with radius " + myCircle.getRadius()+" is " + myCircle.findArea());

    }
}

package packagePassReference;

public class ChangingValues {

	public static void main(String[] args) {
		Circle myCircle = new Circle(7);
		int num = 7;
		
		System.out.println("Before calling changeValues method: ");
		System.out.println("\nmyCircle.radius = "+myCircle.radius);
		System.out.println("num = "+num);
		
		changeValues(myCircle, num);
		
		System.out.println("\nAfter calling changeValues method: ");
		System.out.println("\nmyCircle.radius = "+myCircle.radius);
		System.out.println("num = "+num);
		
	}
	
	static void changeValues(Circle c, int x)
	{
		x=5;
		c.radius = 5;
	}
}



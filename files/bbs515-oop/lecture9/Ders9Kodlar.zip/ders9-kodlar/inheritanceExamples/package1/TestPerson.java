package inheritanceExamples.package1;


public class TestPerson {

    public static void main(String[] args) {
        Person p = new Person("Ahmet", "Demir");
        System.out.println(p);

    }
}




package stringExamples;

public class TestCharAt {

	public static void main(String[] args) {
		
		String s = "abcdefg";
		
		char c = s.charAt(0);
		System.out.println(c);
		
		c = s.charAt(3);
		System.out.println(c);

	}
}

window.init = function(){    
    Input.enableCursorLock();

    var buddhaCubemap = new CubeMap(
        "https://i.hizliresim.com/0GJk9o.jpg", 
        "https://i.hizliresim.com/d7g2mr.jpg",
        "https://i.hizliresim.com/4GykXJ.jpg",
        "https://i.hizliresim.com/5G6kbl.jpg",
        "https://i.hizliresim.com/JOb4mj.jpg",
        "https://i.hizliresim.com/AyrqWr.jpg"
    );

    var skybox = new Skybox(buddhaCubemap);

    var camera = new Camera();
    camera.position = [0.0, 0, -6];
    camera.lookAt = [0.0, -1.0, 0.0];
    camera.setSkybox(skybox);

    camera.setFreeMove(true);

    
    var simpleProgram = new Program('color-vs', 'color-fs');
    simpleProgram.setVertexPositionAttributeName("aVertexPosition");
    simpleProgram.setVertexColorAttributeName("aVertexColor");

    var simpleMaterial = new Material(simpleProgram);
    
    window.simpleBox = new SceneObject(createSimpleBoxMesh(0.3), simpleMaterial);
    window.simpleBox.localPosition = [0, 0, 0];
}

window.update = function(){
    
}
window.init = function(){    
    Input.enableCursorLock();

    var buddhaCubemap = new CubeMap(
        "https://i.hizliresim.com/0GJk9o.jpg", 
        "https://i.hizliresim.com/d7g2mr.jpg",
        "https://i.hizliresim.com/4GykXJ.jpg",
        "https://i.hizliresim.com/5G6kbl.jpg",
        "https://i.hizliresim.com/JOb4mj.jpg",
        "https://i.hizliresim.com/AyrqWr.jpg"
    );

    var skybox = new Skybox(buddhaCubemap);

    var camera = new Camera();
    camera.position = [0.0, 0, -6];
    camera.lookAt = [0.0, -1.0, 0.0];
    camera.setSkybox(skybox);

    camera.setFreeMove(true);
    
    var environmentMappingProgram = new Program('environmentMapping-vs', 'environmentMapping-fs');
    
    environmentMappingProgram.setVertexPositionAttributeName("aVertexPosition");
    environmentMappingProgram.setVertexTangentAttributeName("aVertexTangent");
    environmentMappingProgram.setVertexBitangentAttributeName("aVertexBitangent");

    environmentMappingProgram.setEnvironmentCubeMapUniformName("uEnvironmentCubemap");
    environmentMappingProgram.setModelMatrixUniformName("uModelMatrix");
    environmentMappingProgram.setCameraPositionUniformName("uCameraPosition");
    
    var environmentMappedMaterial = new Material(environmentMappingProgram);
    environmentMappedMaterial.setEnvironmentCubeMap(buddhaCubemap);

    var teapot = new SceneObject(createTeapotMesh(0.1), environmentMappedMaterial); 
    teapot.localEulerAngles = [-90, 0, 0];
}

window.update = function(){

}
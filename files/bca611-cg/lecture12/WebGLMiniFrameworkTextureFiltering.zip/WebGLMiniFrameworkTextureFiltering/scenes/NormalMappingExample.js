window.init = function(){    
    Input.enableCursorLock();

    var buddhaCubemap = new CubeMap(
        "https://i.hizliresim.com/0GJk9o.jpg", 
        "https://i.hizliresim.com/d7g2mr.jpg",
        "https://i.hizliresim.com/4GykXJ.jpg",
        "https://i.hizliresim.com/5G6kbl.jpg",
        "https://i.hizliresim.com/JOb4mj.jpg",
        "https://i.hizliresim.com/AyrqWr.jpg"
    );

    var skybox = new Skybox(buddhaCubemap);

    var camera = new Camera();
    camera.position = [0.0, 0, -6];
    camera.lookAt = [0.0, -1.0, 0.0];
    camera.setSkybox(skybox);

    camera.setFreeMove(true);


    var diffuseTexture = new Texture("https://upload.wikimedia.org/wikipedia/commons/2/2c/IntP_Brick.png");
    var normalTexture = new Texture("https://upload.wikimedia.org/wikipedia/commons/8/86/IntP_Brick_NormalMap.png");
    
    var normalProgram = new Program('pointLightNormalMapping-vs', 'pointLightNormalMapping-fs');
    
    normalProgram.setVertexPositionAttributeName("aVertexPosition");
    normalProgram.setTextureCoordinateAttributeName("aTextureCoord");
    normalProgram.setVertexTangentAttributeName("aVertexTangent");
    normalProgram.setVertexBitangentAttributeName("aVertexBitangent");

    normalProgram.setTextureUniformName("uDiffuseTexture");
    normalProgram.setNormalTextureUniformName("uNormalTexture");
    normalProgram.setInverseModelMatrixUniformName("uInverseModelMatrix");
    normalProgram.setModelMatrixUniformName("uModelMatrix");
    
    var normalMappedMaterial = new Material(normalProgram);
    normalMappedMaterial.setTexture(diffuseTexture);
    normalMappedMaterial.setNormalTexture(normalTexture);

    var normalBox = new SceneObject(createBoxMeshWithTangents(), normalMappedMaterial); 
    

    window.light = new Light(LightType.Point);
    
    var simpleProgram = new Program('color-vs', 'color-fs');
    simpleProgram.setVertexPositionAttributeName("aVertexPosition");
    simpleProgram.setVertexColorAttributeName("aVertexColor");

    var simpleMaterial = new Material(simpleProgram);
    
    window.lightIndicator = new SceneObject(createSimpleBoxMesh(0.3), simpleMaterial);
    window.lightIndicator.localPosition = [1.5, 1.5, -1.5];
}

window.update = function(){
    if(Input.isKeyDown(Keys.RightArrow)){
        window.lightIndicator.localPosition[0] -= 0.1;
    }
    if(Input.isKeyDown(Keys.LeftArrow)){
        window.lightIndicator.localPosition[0] += 0.1;
    }
    if(Input.isKeyDown(Keys.UpArrow)){
        window.lightIndicator.localPosition[1] += 0.1;
    }
    if(Input.isKeyDown(Keys.DownArrow)){
        window.lightIndicator.localPosition[1] -= 0.1;
    }

    window.light.position[0] = window.lightIndicator.localPosition[0];
    window.light.position[1] = window.lightIndicator.localPosition[1];
    window.light.position[2] = window.lightIndicator.localPosition[2]; 
}
window.init = function(){    
    Input.enableCursorLock();

    var buddhaCubemap = new CubeMap(
        "https://i.hizliresim.com/0GJk9o.jpg", 
        "https://i.hizliresim.com/d7g2mr.jpg",
        "https://i.hizliresim.com/4GykXJ.jpg",
        "https://i.hizliresim.com/5G6kbl.jpg",
        "https://i.hizliresim.com/JOb4mj.jpg",
        "https://i.hizliresim.com/AyrqWr.jpg"
    );

    var skybox = new Skybox(buddhaCubemap);

    var camera = new Camera();
    camera.position = [0.0, 0, -6];
    camera.lookAt = [0.0, -1.0, 0.0];
    camera.setSkybox(skybox);

    camera.setFreeMove(true);


    window.diffuseTexture = new Texture("https://upload.wikimedia.org/wikipedia/commons/2/2c/IntP_Brick.png");
    window.normalTexture = new Texture("https://upload.wikimedia.org/wikipedia/commons/8/86/IntP_Brick_NormalMap.png");
    
    var normalProgram = new Program('pointLightNormalMapping-vs', 'pointLightNormalMapping-fs');
    
    normalProgram.setVertexPositionAttributeName("aVertexPosition");
    normalProgram.setTextureCoordinateAttributeName("aTextureCoord");
    normalProgram.setVertexTangentAttributeName("aVertexTangent");
    normalProgram.setVertexBitangentAttributeName("aVertexBitangent");

    normalProgram.setTextureUniformName("uDiffuseTexture");
    normalProgram.setNormalTextureUniformName("uNormalTexture");
    normalProgram.setInverseModelMatrixUniformName("uInverseModelMatrix");
    normalProgram.setModelMatrixUniformName("uModelMatrix");
    
    var normalMappedMaterial = new Material(normalProgram);
    normalMappedMaterial.setTexture(window.diffuseTexture);
    normalMappedMaterial.setNormalTexture(window.normalTexture);

    var normalBox = new SceneObject(createBoxMeshWithTangents(), normalMappedMaterial); 
    

    window.light = new Light(LightType.Point);
    
    var simpleProgram = new Program('color-vs', 'color-fs');
    simpleProgram.setVertexPositionAttributeName("aVertexPosition");
    simpleProgram.setVertexColorAttributeName("aVertexColor");

    var simpleMaterial = new Material(simpleProgram);
    
    window.lightIndicator = new SceneObject(createSimpleBoxMesh(0.3), simpleMaterial);
    window.lightIndicator.localPosition = [1.5, 1.5, -1.5];

    window.anisotropicButton = createButton("Anisotropic : <b>false</b>", window.switchAnisotropic);
    window.mipmapButton = createButton("Mipmap : <b>false</b>", window.switchMipmap);
    window.effectNormalButton = createButton("Effect Normals : <b>false</b>", window.switchEffectNormals);
    
    
}

var isAnisotropicOn = false;
var isMipmapOn = false;
var isEffectNormal = false;

window.switchAnisotropic = function(){
    if(isAnisotropicOn){
        window.diffuseTexture.setAnisotropicFiltering(1);
        if(isEffectNormal)
            window.normalTexture.setAnisotropicFiltering(1);
    }else{
        window.diffuseTexture.setAnisotropicFiltering(16);
        if(isEffectNormal)        
            window.normalTexture.setAnisotropicFiltering(16);
        isMipmapOn = true;
    }
    isAnisotropicOn = !isAnisotropicOn;
    window.anisotropicButton.innerHTML = "Anisotropic : <b>"+isAnisotropicOn+"</b>";
}

window.switchMipmap = function(){
    isMipmapOn = !isMipmapOn;
    window.diffuseTexture.setMipMap(isMipmapOn);
    if(isEffectNormal)    
        window.normalTexture.setMipMap(isMipmapOn);
    window.mipmapButton.innerHTML = "Mipmap : <b>"+isMipmapOn+"</b>";
}

window.switchEffectNormals = function(){
    isEffectNormal = !isEffectNormal;
    window.effectNormalButton.innerHTML = "Effect Normals : <b>"+isEffectNormal+"</b>";
    
}

window.update = function(){
    if(Input.isKeyDown(Keys.RightArrow)){
        window.lightIndicator.localPosition[0] -= 0.1;
    }
    if(Input.isKeyDown(Keys.LeftArrow)){
        window.lightIndicator.localPosition[0] += 0.1;
    }
    if(Input.isKeyDown(Keys.UpArrow)){
        window.lightIndicator.localPosition[1] += 0.1;
    }
    if(Input.isKeyDown(Keys.DownArrow)){
        window.lightIndicator.localPosition[1] -= 0.1;
    }

    window.light.position[0] = window.lightIndicator.localPosition[0];
    window.light.position[1] = window.lightIndicator.localPosition[1];
    window.light.position[2] = window.lightIndicator.localPosition[2]; 
}
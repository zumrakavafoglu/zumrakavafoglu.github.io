var mvMatrix = mat4.create(),
    pMatrix = mat4.create();

var cameraPosition;

var lookAtPosition;

var globalUp = [0, 1, 0];

window.init = function(){
    setupBuffers();

    getMatrixUniforms();
}

window.update = function(){
    clearScene();

    animateCameraPosition();

    calculateViewMatrix(lookAtPosition, cameraPosition, globalUp);

    setMatrixUniforms();
    
    drawScene();
}

function setupBuffers(){
    //TODO: create and fill the vertex buffers here for the model you want
    //You should create the model using indexed triangle list with an efficient indexing
}

function clearScene(){
    gl.clearColor(0.0, 0.0, 0.0, 1.0); 	
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT); 	
    gl.enable(gl.DEPTH_TEST);    
    
    gl.viewport(0, 0, canvas.width, canvas.height);
    mat4.perspective(pMatrix, 45, canvas.width / canvas.height, 0.1, 100.0);
}

function animateCameraPosition(){
    //TODO: animate cameraPosition 
}

function calculateViewMatrix(at, eye, up){
    //TODO: implement
    //fill mvMatrix
}

function drawScene(){
    //TODO: Bind your buffers and draw
}

function getMatrixUniforms(){
    glProgram.pMatrixUniform = gl.getUniformLocation(glProgram, "uPMatrix");
    glProgram.mvMatrixUniform = gl.getUniformLocation(glProgram, "uMVMatrix");          
}

function setMatrixUniforms() {
    gl.uniformMatrix4fv(glProgram.pMatrixUniform, false, pMatrix);
    gl.uniformMatrix4fv(glProgram.mvMatrixUniform, false, mvMatrix);
}
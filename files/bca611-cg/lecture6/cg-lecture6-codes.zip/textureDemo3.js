var xRotationValue = 0;
var yRotationValue = 0;
var zRotationValue = 0;

function xRotation(vol) {
    var xRotation = document.querySelector("#slider1");
	xRotation.value = vol;
    xRotationValue = vol; 
    xRotation.style.left = vol;    
}
function yRotation(vol) {
    var yRotation = document.querySelector("#slider2");
	yRotation.value = vol;
    yRotationValue = vol; 
    yRotation.style.left = vol;    
}
function zRotation(vol) {
    var zRotation = document.querySelector("#slider3");
	zRotation.value = vol;
    zRotationValue = vol; 
    zRotation.style.left = vol;  
}


var vertexPositionAttribute = null,
    cubeVerticesBuffer = null,
    vertexColorAttribute = null,
    cubeColorBuffer = null,
    cubeVerticesIndexBuffer = null;
    textureCoordsBuffer = null;
    textureCoordsAttribute = null;

var mvMatrix = mat4.create(),
    viewMatrix = mat4.create(),
    modelMatrix = mat4.create(),
    pMatrix = mat4.create(),
    RyMatrix = mat4.create(),
    RzMatrix = mat4.create(),
    RxMatrix = mat4.create();

var angleX=0,
    angleY=0,
    angleZ = 0,
    camera_x = 0,
    camera_x_translation = 0.01,
    cameraPosition;

var texInfo;

var lookAtPosition = [0.5, 0.5, 0.5];

var globalUp = [0, 1, 0];

window.init = function(){
    setupBuffers();
    getMatrixUniforms();


    function loadImageAndCreateTextureInfo(url) {
        var tex = gl.createTexture();
        gl.bindTexture(gl.TEXTURE_2D, tex);
        // Fill the texture with a 1x1 blue pixel.
        gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, 1, 1, 0, gl.RGBA, gl.UNSIGNED_BYTE,
                      new Uint8Array([0, 0, 255, 255]));
       
        // let's assume all images are not a power of 2
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
       
        var textureInfo = {
          width: 1,   // we don't know the size until it loads
          height: 1,
          texture: tex,
        };

        var img = new Image();
        img.crossOrigin = ""; 
        
        img.addEventListener('load', function() {
          textureInfo.width = img.width;
          textureInfo.height = img.height;
       
          gl.bindTexture(gl.TEXTURE_2D, textureInfo.texture);
          gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, img);
               // gl.generateMipmap(gl.TEXTURE_2D);

        });
        img.src = url;
       
        return textureInfo;
      }

      //loadImageAndCreateTextureInfo('https://c1.staticflickr.com/9/8873/18598400202_3af67ef38f_q.jpg');
      //loadImageAndCreateTextureInfo('https://i.imgur.com/BVwbgof.jpg');
      loadImageAndCreateTextureInfo('https://webglfundamentals.org/webgl/resources/f-texture.png');
      
      
}

window.update = function(){
    clearScene();

    calculateModelViewMatrix();

    setMatrixUniforms();
    
    drawScene();
}

function calculateViewMatrix(){
    var cameraTransX = 0;
    var cameraTransY = 0;
    var cameraTransZ = 3;

    viewMatrix = mat4.fromValues(
                    1,0,0,-cameraTransX,
                    0,1,0,-cameraTransY,
                    0,0,1,-cameraTransZ,
                    0,0,0,1
                );

    mat4.transpose(viewMatrix, viewMatrix);
}

function calculateModelMatrix(){

    var str = "";

    mat4.identity(modelMatrix);
    
    angleX = xRotationValue;
    RxMatrix = mat4.fromValues(
                                1,0,0,0,
                                0, math.cos(math.unit(angleX,'deg')), -math.sin(math.unit(angleX,'deg')), 0,
                                0, math.sin(math.unit(angleX,'deg')), math.cos(math.unit(angleX,'deg')), 0,
                                0,0,0,1
                            );

    RxMatrix = mat4.transpose(RxMatrix, RxMatrix);
    str += "angleX : " + angleX +"<br>";
   // mat4.identity(RxMatrix);

    angleY = yRotationValue;  
    RyMatrix = mat4.fromValues(
                                math.cos(math.unit(angleY,'deg')),0,math.sin(math.unit(angleY,'deg')),0,
                                0,1,0,0,
                                -math.sin(math.unit(angleY,'deg')),0, math.cos(math.unit(angleY,'deg')), 0,
                                0,0,0,1
                            );

    RyMatrix = mat4.transpose(RyMatrix, RyMatrix);

    str += "angleY : " + angleY +"<br>";
  //  mat4.identity(RyMatrix);
    

    angleZ = zRotationValue;
    RzMatrix = mat4.fromValues(
                                math.cos(math.unit(angleZ,'deg')), -math.sin(math.unit(angleZ,'deg')), 0, 0,
                                math.sin(math.unit(angleZ,'deg')), math.cos(math.unit(angleZ,'deg')), 0, 0,
                                0,0,1,0,
                                0,0,0,1
                            );

    RzMatrix = mat4.transpose(RzMatrix, RzMatrix);
    //mat4.identity(RzMatrix);  
  
    str += "angleZ : " + angleZ;

 //Forms modelMatrix for Euler rotation in XYZ order
 //Since we rotate around y with 90 degrees, rotation around x and z axis gives rotation around the same axis.
  modelMatrix = mat4.multiply(modelMatrix, modelMatrix, RzMatrix);
  modelMatrix = mat4.multiply(modelMatrix, modelMatrix, RyMatrix) ;  
  modelMatrix = mat4.multiply(modelMatrix, modelMatrix, RxMatrix) ;
    
}

function calculateModelViewMatrix(){

    mat4.identity(mvMatrix);
    calculateViewMatrix();
    calculateModelMatrix();
    mvMatrix = mat4.multiply(mvMatrix,viewMatrix,modelMatrix);

}

function clearScene()
{
    gl.clearColor(0.0, 0.0, 0.0, 1.0); 	
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
    gl.enable(gl.DEPTH_TEST);
    
    gl.viewport(0, 0, canvas.width, canvas.height);
    mat4.perspective(pMatrix, 45, canvas.width / canvas.height, 0.1, 100.0);
}

function setupBuffers()
{
    var cubeVertices = [

        //bottomFace
      -0.5,-0.5,-0.5,
      0.5,-0.5,-0.5,
      -0.5,-0.5,0.5,
      0.5,-0.5,-0.5,
      -0.5,-0.5,0.5,
      0.5,-0.5,0.5,

      
      //rightFace
      0.5,-0.5,-0.5,
      0.5,-0.5,0.5,
      0.5,0.5,0.5,
      0.5,-0.5,-0.5,
      0.5,0.5,0.5,
      0.5,0.5,-0.5,

     
      //topFace
      0.5,0.5,0.5,
      -0.5,0.5,0.5,
      0.5,0.5,-0.5,
      -0.5,0.5,0.5,
      -0.5,0.5,-0.5,
      0.5,0.5,-0.5,

   

    //rearFace
    -0.5,-0.5,0.5,
    0.5,-0.5,0.5,
    0.5,0.5,0.5,
    -0.5,-0.5,0.5,
    0.5,0.5,0.5,
    -0.5,0.5,0.5,

  
   
    //frontFace
    0.5,-0.5,-0.5,
    0.5,0.5,-0.5,
    -0.5,0.5,-0.5,
    -0.5,-0.5,-0.5,
    0.5,-0.5,-0.5,
    -0.5,0.5,-0.5,


    //leftFace
    -0.5,-0.5,-0.5,
    -0.5,-0.5,0.5,
    -0.5,0.5,0.5,
    -0.5,-0.5,-0.5,
    -0.5,0.5,0.5,
    -0.5,0.5,-0.5

    
    ];
    cubeVerticesBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, cubeVerticesBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(cubeVertices), gl.STATIC_DRAW);	

    var textureCoords = [
        //bottomFace
       /* 0,0,
        1,0,
        0,1,
        1,0,
        0,1,
        1,1,*/

        0,-0.3,
        1,-0.3,
        0,1.3,
        1,-0.3,
        0,1.3,
        1,1.3,


        //rightFace
        1,1,
        0,1,
        0,0,
        1,1,
        0,0,
        1,0,

        //topFace
       /* 1,1,
        0,1,
        1,0,
        0,1,
        0,0,
        1,0,*/

       0.7,0.7,
        0.3,0.7,
        0.7,0.3,
        0.3,0.7,
        0.3,0.3,
        0.7,0.3,
    


        //rearFace
        0,1,
        1,1,
        1,0,
        0,1,
        1,0,
        0,0,

        //frontFace
        1,1,
        1,0,
        0,0,
        0,1,
        1,1,
        0,0,

       

        //leftFace
        1,1,
        0,1,
        0,0,
        1,1,
        0,0,
        1,0

    ]

    textureCoordsBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, textureCoordsBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(textureCoords), gl.STATIC_DRAW);	

}

function drawScene()
{
    vertexPositionAttribute = gl.getAttribLocation(glProgram, "aVertexPosition");
    gl.enableVertexAttribArray(vertexPositionAttribute);
    gl.bindBuffer(gl.ARRAY_BUFFER, cubeVerticesBuffer);
    gl.vertexAttribPointer(vertexPositionAttribute, 3, gl.FLOAT, false, 0, 0);

    textureCoordsAttribute = gl.getAttribLocation(glProgram, "aTextureCoord");
    gl.enableVertexAttribArray(textureCoordsAttribute);
    gl.bindBuffer(gl.ARRAY_BUFFER, textureCoordsBuffer);
    gl.vertexAttribPointer(textureCoordsAttribute, 2, gl.FLOAT, false, 0, 0);

    gl.drawArrays(gl.TRIANGLES, 0, 36);
  
}

function getMatrixUniforms(){
    glProgram.pMatrixUniform = gl.getUniformLocation(glProgram, "uPMatrix");
    glProgram.mvMatrixUniform = gl.getUniformLocation(glProgram, "uMVMatrix");          
}

function setMatrixUniforms() {
    gl.uniformMatrix4fv(glProgram.pMatrixUniform, false, pMatrix);
    gl.uniformMatrix4fv(glProgram.mvMatrixUniform, false, mvMatrix);
}
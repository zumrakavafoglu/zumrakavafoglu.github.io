

window.init = function(){
    var camera = new Camera();
    camera.position = [0, 3, -7];
    camera.lookAt = [1.0, 2.0, 0.0];

    var program1 = new Program('color-vs', 'color-fs');
    program1.setVertexPositionAttributeName("aVertexPosition");
    program1.setVertexColorAttributeName("aVertexColor");

    var material1 = new Material(program1);

    var pyramid = new SceneObject(createPyramidMesh(), material1);

    pyramid.localPosition = [2, 0, 0];

    var fTexture = new Texture('https://webglfundamentals.org/webgl/resources/f-texture.png');
    
    var texturedProgram = new Program('textured-vs', 'textured-fs');
    texturedProgram.setVertexPositionAttributeName("aVertexPosition");
    texturedProgram.setTextureCoordinateAttributeName("aTextureCoord");
    
    var texturedMaterial = new Material(texturedProgram);
    texturedMaterial.setTexture(fTexture);

    window.box = new SceneObject(createBoxMesh(), texturedMaterial); 
    pyramid.parent = box;

    var slider1 = createSlider("Euler Angle Y : ", 0, 0, 360, function(){
        window.box.localEulerAngles = [0, this.value, 0];
    });

    var button1 = createButton("Test", function(){
        alert("Deneme");
    });

}

window.update = function(){
    window.mainCamera.update();

    drawSceneObjects();
}

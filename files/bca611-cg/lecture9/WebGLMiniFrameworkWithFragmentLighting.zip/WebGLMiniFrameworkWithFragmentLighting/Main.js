

window.init = function(){
    var camera = new Camera();
    camera.position = [0, 0, -2];
    camera.lookAt = [0.0, 0.0, 0.0];

   /* var program1 = new Program('color-vs', 'color-fs');
    program1.setVertexPositionAttributeName("aVertexPosition");
    program1.setVertexColorAttributeName("aVertexColor");

    var material1 = new Material(program1);

    var pyramid = new SceneObject(createPyramidMesh(), material1);

    pyramid.localPosition = [2, 0, 0];

    var fTexture = new Texture('https://webglfundamentals.org/webgl/resources/f-texture.png');
    
    var texturedProgram = new Program('textured-vs', 'textured-fs');
    texturedProgram.setVertexPositionAttributeName("aVertexPosition");
    texturedProgram.setTextureCoordinateAttributeName("aTextureCoord");
    
    var texturedMaterial = new Material(texturedProgram);
    texturedMaterial.setTexture(fTexture);

    window.box = new SceneObject(createBoxMesh(), texturedMaterial); 
    pyramid.parent = box;*/

     //per vertex lighting 
    //without texture
    /*var lightProgram = new Program('directionalLight-vs', 'directionalLight-fs');
    
        lightProgram.setVertexPositionAttributeName("aVertexPosition");
        lightProgram.setVertexNormalAttributeName("aVertexNormal");
        
        lightProgram.setDiffuseProductUniformName("uDiffuseProduct");
        lightProgram.setSpecularProductUniformName("uSpecularProduct");
        lightProgram.setAmbientProductUniformName("uAmbientProduct");
        lightProgram.setShininessUniformName("uShininess");
           
        var material = new Material(lightProgram);
    
        loadObjMesh("https://zumrakavafoglu.github.io/files/bca611-cg/models/smoothSphere.obj",function(mesh){
            window.sphere = new SceneObject(mesh, material); 
        });
    */
    //per fragment lighting 
    //with texture
    var lightProgram = new Program('directionalLight2-vs', 'directionalLight2-fs');

    lightProgram.setVertexPositionAttributeName("aVertexPosition");
    lightProgram.setVertexNormalAttributeName("aVertexNormal");
    //for texture
    lightProgram.setTextureCoordinateAttributeName("aTextureCoord");

    lightProgram.setDiffuseProductUniformName("uDiffuseProduct");
    lightProgram.setSpecularProductUniformName("uSpecularProduct");
    lightProgram.setAmbientProductUniformName("uAmbientProduct");
    lightProgram.setShininessUniformName("uShininess");

    var fTexture = new Texture('https://webglfundamentals.org/webgl/resources/f-texture.png');
   
    var material = new Material(lightProgram);
    material.setTexture(fTexture);

    loadObjMesh("https://zumrakavafoglu.github.io/files/bca611-cg/models/smoothSphere.obj",function(mesh){
        window.sphere = new SceneObject(mesh, material); 
    });
    
   /* var material = new Material(lightProgram);
    
    window.sphere = new SceneObject(createSimpleBoxMesh(), material); */

   // var directionalLightPerVertex = new Program('directionalLight-vs', 'directionalLight-fs');
   //lightProgram.setVertexPositionAttributeName("aVertexPosition");
    //directionalLightPerVertex.setTextureCoordinateAttributeName("aTextureCoord");
    //TODO: add  setVertexNormalAttributeName to Program.js
   // lightProgram.setVertexNormalAttributeName("aVertexNormal");
   
    
    new Light(LightType.Directional);

    var slider1 = createSlider("Euler Angle Y : ", 0, 0, 360, function(){
        window.sphere.localEulerAngles = [0, this.value, 0];
    });

    var dirXSlider = createSlider("Light Direction X : ", window.light.direction[0], -1, 1, function(){
        window.light.direction[0] = this.value;
    });

    var dirYSlider = createSlider("Light Direction Y : ", window.light.direction[1], -1, 1, function(){
        window.light.direction[1] = this.value;
    });

    var dirZSlider = createSlider("Light Direction Z : ", window.light.direction[2], -1, 1, function(){
        window.light.direction[2] = this.value;
    });

    var shininessSlider = createSlider("Shininess : ", material.shininess, 1, 100, function(){
        material.shininess = this.value;
    });

    var button1 = createButton("Test", function(){
        alert("Deneme");
    });

}

window.update = function(){
    window.mainCamera.update();

    drawSceneObjects();
}

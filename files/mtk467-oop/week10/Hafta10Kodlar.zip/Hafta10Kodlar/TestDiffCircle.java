import packageDiffCircle.Circle;

public class TestDiffCircle {
    public static void main(String[] args){

        //Create a circle with radius 5.0
        Circle myCircle = new Circle(5.0);

        System.out.println("Radius of circle: "+myCircle.getRadius());
        System.out.println("Area of circle: "+myCircle.findArea());
        System.out.println("Perimeter of circle: "+myCircle.findPerimeter());
    }
}

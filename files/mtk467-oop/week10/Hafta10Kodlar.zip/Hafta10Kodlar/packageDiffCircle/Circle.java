
package packageDiffCircle;

public class Circle {
	private double radius;

	public Circle(){
		radius = 1.0;
	}

	public Circle(double r){
		setRadius(r);
	}

	public double getRadius(){
		return radius;
	}

	public void setRadius(double newRadius){
		if(newRadius<=0){
			System.out.println("Warning: Radius must be positive, " +
					"it's set to default value 1 ");
			radius = 1;
		}else{
			radius = newRadius;
		}
	}

	public double findArea(){
		return radius*radius*Math.PI;
	}

	public double findPerimeter(){
		return 2*Math.PI*radius;
	}
}

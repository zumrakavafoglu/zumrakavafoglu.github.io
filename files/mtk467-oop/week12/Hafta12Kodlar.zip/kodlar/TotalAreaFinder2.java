public class TotalAreaFinder2 {

    public static void main(String[] args) {
        Circle myCircle = new Circle(4, "green");
        Rectangle myRectangle = new Rectangle(3, 5, "blue");
        Cylinder myCylinder = new Cylinder(7, "red", 2);

        GeometricObject[] myGeometricObjects = {myCircle, myRectangle, myCylinder};

        System.out.printf("Total area of the objects in the scene is %.2f",
                calculateTotalArea(myGeometricObjects));

    }

    public static double calculateTotalArea(GeometricObject[] geometricObjects){
        double totalArea = 0;

        for(int i=0; i<geometricObjects.length; i++){
            totalArea += geometricObjects[i].findArea();
        }

        return totalArea;
    }
}

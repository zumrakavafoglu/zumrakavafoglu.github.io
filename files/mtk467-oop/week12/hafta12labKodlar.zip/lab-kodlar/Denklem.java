public abstract class Denklem {

    protected double[] katsayilar;

    protected int terimSayisi;

    protected Denklem(int terimSayisi){
        setTerimSayisi(terimSayisi);
        katsayilar = new double[this.terimSayisi];
        for(int i=0; i<katsayilar.length; i++)
            katsayilar[i] = 1;
    }

    protected Denklem(double[] katsayilar, int terimSayisi){

        setTerimSayisi(terimSayisi);
        this.katsayilar = new double[this.terimSayisi];
        setKatsayilar(katsayilar);
    }

    protected void setTerimSayisi(int terimSayisi){
        if(terimSayisi < 3 )
            this.terimSayisi = 3;
        else
            this.terimSayisi = terimSayisi;
    }

    public int getTerimSayisi(){
        return terimSayisi;
    }

    public void setKatsayilar(double[] katsayilar) {
        if(katsayilar.length != this.terimSayisi){
            for(int i=0; i<this.katsayilar.length; i++){
                this.katsayilar[i] = 1;
            }
        }else {
            System.arraycopy(katsayilar, 0, this.katsayilar, 0, this.katsayilar.length);
        }
    }

    public double[] getKatsayilar(){
        return katsayilar;
    }

    public abstract boolean cozumVarmi();
    public abstract double[] coz();
}

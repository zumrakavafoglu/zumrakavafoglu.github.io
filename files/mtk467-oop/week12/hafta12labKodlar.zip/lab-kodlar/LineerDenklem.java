public class LineerDenklem extends Denklem{

    public LineerDenklem(){
        super(3);
    }

    public LineerDenklem(double[] katsayilar){
        super(katsayilar,3);
    }


   public boolean cozumVarmi(){

        return true;
    }

    public double[] coz(){

        double[] cozum = new double[1];
        cozum[0] = (katsayilar[2] - katsayilar[1]) / katsayilar[0];

        return cozum;
    }

}

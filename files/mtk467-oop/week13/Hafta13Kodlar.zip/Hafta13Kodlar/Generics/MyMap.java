
public class MyMap<T, S> {

    private Pair<T, S> firstPair;

    private Pair<T, S> getPair(T key){

        if(key == null){
            System.out.println("Parameter key is null");
            return null;
        }

        Pair<T, S> pair = firstPair;
        while (pair != null){

            if(pair.getKey().equals(key)){
                return pair;
            }

            pair = pair.getNext();
        }

        return null;
    }


    public void put(T key, S value){

        if(this.isEmpty()){
            firstPair = new Pair<T, S>(key, value);
        }
        else{
            Pair<T, S> pair = this.getPair(key);

            if(pair != null){
                pair.setValue(value);
            }else{
                this.getLast().setNext(new Pair<T, S>(key, value));
            }
        }
    }

    private Pair<T,S> getLast(){

        if(this.isEmpty())
            return null;

        Pair<T,S> lastPair = firstPair;

        while(lastPair.getNext() != null){
            lastPair = lastPair.getNext();
        }

        return lastPair;
    }

    public S get(T key){

        Pair<T, S> pair = this.getPair(key);

        if(pair != null)
            return pair.getValue();

        return null;

    }

    public boolean isEmpty(){
        return firstPair == null;
    }

    private Pair<T, S> getPrevious(Pair<T, S> pair){

        if(pair == null)
            return null;

        Pair<T, S> tempPair = firstPair;

        while (tempPair!= null){

            if(tempPair.getNext() == pair)
                return tempPair;

            tempPair = tempPair.getNext();
        }

        return null;
    }

    public S remove(T key){

        Pair<T, S> pair = this.getPair(key);

        if(pair != null){
            this.getPrevious(pair).setNext(pair.getNext());
            return pair.getValue();
        }

        System.out.println("Cannot remove");
        return null;

    }

    public void clear(){
        firstPair = null;
    }

    public boolean containsKey(T key) {

        return this.getPair(key) != null;

    }

    public String toString(){

        System.out.println("Map: ");

        if(isEmpty())
            return "Empty Map";

        String output = "";

        Pair<T, S> pair = firstPair;

        while (pair != null){
            output += pair;
            pair = pair.getNext();
        }

        return output;
    }

}

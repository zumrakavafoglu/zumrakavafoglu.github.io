public class Pair<T ,S> {

    private T key;
    private S value;

    private Pair<T,S> next;

    public Pair(T key, S value) {
        this.key = key;
        this.value = value;
    }

    public T getKey() {
        return key;
    }

    public void setKey(T key) {
        this.key = key;
    }

    public S getValue() {
        return value;
    }

    public void setValue(S value) {
        this.value = value;
    }

    public void setNext(Pair<T, S> next) {
        this.next = next;
    }

    public Pair<T,S> getNext(){
        return next;
    }

    public String toString(){
        if(key == null || value == null )
            return "";

        String output = "[ ";

        output += key;
        output += ", ";
        output += value;
        output += " ]\n";

        return output;
    }

}

public class Stack<E> {


    private final int size; // number of elements in the stack

    private int top; // location of the top element

    private E[] elements; // array that stores stack elements

    // no-argument constructor creates a stack of the default size

    public Stack() {

        this(10); // default stack size

    } // end no-argument Stack constructor

    public Stack( int s )

    {
        size = s > 0 ? s : 10; // set size of Stack

        top = -1; // Stack initially empty
        elements = ( E[] ) new Object[ size ]; // create array

    } // end Stack constructor

    // push element onto stack; if successful, return true;

    public void push( E pushValue )

    {
        if ( top == size - 1 ){ // if stack is full
            System.out.println("Stack is full, cannot push " + pushValue );
        }
        else
            elements[ ++top ] = pushValue; // place pushValue on Stack
    } // end method push

// return the top element if not empty; else throw EmptyStackException

    public E pop()
    {
        if ( top == -1 ) { // if stack is empty
            System.out.println("Stack is empty, cannot pop");
            return null;
        }

        return elements[ top-- ]; // remove and return top element of Stack
    } // end method pop

} // end class Stack< E >

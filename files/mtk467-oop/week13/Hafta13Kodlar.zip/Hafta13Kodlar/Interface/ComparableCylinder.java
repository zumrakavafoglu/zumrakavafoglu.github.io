
public class ComparableCylinder extends Cylinder implements IComparable {

	public ComparableCylinder(double radius, double height) {
		super(radius,height);
	}
	
	@Override
	public int compareTo(Object o) {

	    if(o instanceof ComparableCylinder){
            if(findVolume() > ((ComparableCylinder)o).findVolume())
                return 1;
            else if (findVolume() < ((ComparableCylinder)o).findVolume())
                return -1;
            else return 0;
        }
		else
			return 0;
	}

}



public class CylinderWithCenter extends Cylinder implements IComparable{
    double centerX, centerY;

    public CylinderWithCenter(){
        this(1,1,0,0);
    }

    public CylinderWithCenter(double radius, double height, double centerX, double centerY){

        super(radius, height);
        this.centerX = centerX;
        this.centerY = centerY;
    }

    @Override
    public int compareTo(Object o) {
        if(findVolume()>((Cylinder)o).findVolume())
            return 1;
        else if (findVolume()<((Cylinder)o).findVolume())
            return -1;
        else
            return 0;
    }
}

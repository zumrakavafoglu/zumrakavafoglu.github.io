
public interface IComparable {

	public int compareTo(Object o);
}

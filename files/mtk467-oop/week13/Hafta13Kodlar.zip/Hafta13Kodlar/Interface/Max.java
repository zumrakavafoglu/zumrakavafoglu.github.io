
public class Max {

	public static IComparable max(IComparable o1, IComparable o2)
	{
		if(o1.compareTo(o2)>0)
			return o1;
		else
			return o2;
	}
}

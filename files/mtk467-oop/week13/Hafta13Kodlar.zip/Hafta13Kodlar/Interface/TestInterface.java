
public class TestInterface {

	public static void main(String[] args) {
		ComparableCircle circle1 = new ComparableCircle(5);
		ComparableCircle circle2 = new ComparableCircle(4);
		
		IComparable circle = Max.max(circle1, circle2);
		System.out.println("The max circle's radius is " + ((Circle)circle).getRadius());
		System.out.println(circle);

		ComparableCylinder cylinder1 = new ComparableCylinder(5, 2);
		ComparableCylinder cylinder2 = new ComparableCylinder(4, 5);
		
		IComparable cylinder = Max.max(cylinder1, cylinder2);

		System.out.println("\ncylinder1's volume is "+cylinder1.findVolume());
		System.out.println("cylinder2's volume is "+cylinder2.findVolume());
		System.out.println("The max cylinder's \tradius is "
				+ ((Cylinder)cylinder).getRadius()
				+ "\n\t\t\theight is "+((Cylinder)cylinder).getHeight()
				+ "\n\t\t\tvolume is "+((Cylinder)cylinder).findVolume());
		System.out.println(cylinder);

	}
}

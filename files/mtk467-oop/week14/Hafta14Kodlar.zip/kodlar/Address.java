import java.util.Objects;

public class Address {

    private int houseNumber;
    private String street;
    private String city;
    private String country;

    Address(int houseNumber, String street, String city, String country){
        this.houseNumber = houseNumber;
        this.street = street;
        this.city = city;
        this.country = country;
    }

    public int getHouseNumber() {
        return houseNumber;
    }

    public void setHouseNumber(int houseNumber) {
        this.houseNumber = houseNumber;
    }

    public String getStreet() {
        return street;
    }

    public void setStreet(String street) {
        this.street = street;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    @Override
    public String toString() {
        return street + " No: " + houseNumber + " - " + city + " / " + country ;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;

        Address address = (Address) o;

        if (houseNumber != address.houseNumber)
            return false;
        if (!street.equals(address.street))
            return false;
        if (!city.equals(address.city))
            return false;
        if (!country.equals(address.country))
            return false;

        return true;
    }

    @Override
    public int hashCode() {

       return Objects.hash(houseNumber, street, city, country);
    }

}

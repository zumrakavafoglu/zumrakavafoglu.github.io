public class ComparableTest2 {

    public static void main(String[] args){

        Circle2 c2 = new Circle2(3.0);

        Rectangle r1 = new Rectangle(2,3);

        //causes compile-term error
        //System.out.print(c2.compareTo(r1));

    }
}

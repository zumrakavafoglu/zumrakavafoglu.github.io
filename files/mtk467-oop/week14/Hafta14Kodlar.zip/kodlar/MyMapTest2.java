import java.util.Scanner;

public class MyMapTest2 {

    public static void main(String[] args){

        MyMap<Address, Long> addressPhoneMap = new MyMap<Address, Long>();

        addressPhoneMap.put(new Address(13, "Sumak Sk.", "Ankara", "Turkiye"), 3122112321L);
        addressPhoneMap.put(new Address(2, "Moda Sk.", "Istanbul", "Turkiye"), 2123458989L);
        addressPhoneMap.put(new Address(13, "Sumak Sk.", "Ankara", "Turkiye"), 3126572321L);

        System.out.println(addressPhoneMap);

    }
}

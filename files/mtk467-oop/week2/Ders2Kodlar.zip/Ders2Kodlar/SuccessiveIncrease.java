
//Zumra Kavafoglu
//02.10.2017

//Program for increasing the value of
// an integer successively
public class SuccessiveIncrease {
    public static void main(String args[]) {

        int sum;

        sum = 0;

        sum = sum + 3;

        sum += 7;

        System.out.printf("Total sum is %d", sum);

    }

}

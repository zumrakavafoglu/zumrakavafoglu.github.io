
//Zumra Kavafoglu
//09.10.2017
//Demo program for ArithmeticException

public class ArithmeticExceptionDemo {
    public static void main(String[] args) {

       int x = 3/0;

       System.out.println(x);
    }
}


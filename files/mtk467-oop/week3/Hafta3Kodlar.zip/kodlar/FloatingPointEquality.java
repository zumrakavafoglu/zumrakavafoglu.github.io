

//Zumra Kavafoglu
//09.10.2017
//Demo program for checking floating point number equality

public class FloatingPointEquality {

    public static void main(String[] args)
    {
        final double EPS = 1.0E-14;

        double sinX;

        sinX = Math.sin(2*Math.PI);

        System.out.print("Equality test : ");

        if(sinX==0)
            System.out.println("sin(2*PI) is equal to zero");
        else
            System.out.println("sin(2*PI) is NOT equal to zero");

        System.out.print("\nApproximate equality test : ");

        if( Math.abs(sinX-0.0) < EPS )
            System.out.println("sin(2*PI) is equal to zero");
        else
            System.out.println("sin(2*PI) is NOT equal to zero");

        System.out.println("\nReal values :");
        System.out.println("sin(2*PI) = " + sinX);

    }
}

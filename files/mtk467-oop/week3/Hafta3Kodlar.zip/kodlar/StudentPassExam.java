import java.util.Scanner;

public class StudentPassExam {

    public static void main(String[] args) {

        final double passingGrade = 55;

        double grade;

        Scanner input = new Scanner(System.in);

        System.out.println("Enter student's grade: ");

        grade = input.nextDouble();

        if(grade >= passingGrade) {
            System.out.println("Student passed the exam");
            System.out.println("Congrats");
        }
    }
}

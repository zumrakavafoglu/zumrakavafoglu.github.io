//Zumra Kavafoglu
//09.10.2017
//Program for printing "Welcome to Java" for a hundred times

import java.util.Scanner;

public class ForDemo {

    public static void main(String[] args) {

        for(int i=0; i<100; i++){

            System.out.println("Welcome to Java");

        }

    }
}

//Zumra Kavafoglu
//09.10.2017
//Program for calculating the multiplication of odd numbers from 1 to n

import java.util.Scanner;

public class OddMultiplication
{
	public static void main(String[] args)
	{
		int n;

		int multiplication;

		System.out.print("Enter a positive integer: ");

		Scanner input = new Scanner(System.in);

		n = input.nextInt();

		if(n < 0){

			System.out.print("Wrong number");

		}else{

			multiplication = 1;

			for(int i = 1 ; i <= n ; i += 2)
			{
				multiplication *= i;
			}

			System.out.printf("Multiplication of odd numbers from 1 to %d is %d",n, multiplication);
		}

	}
}
//Zumra Kavafoglu
//09.10.2017
//Program for adding integers till their sum is >= 6

public class TestBreak {

	public static void main(String[] args) {
		
		int sum = 0;
		int item = 0;
		
		while(item < 5)
		{
			item++;
			System.out.println("Item is now: "+item);
			sum += item;
			System.out.println("Sum is now: "+sum);
			if(sum >= 6)
				break;
		}
		
		System.out.println("The last sum is: "+sum);
	}
}

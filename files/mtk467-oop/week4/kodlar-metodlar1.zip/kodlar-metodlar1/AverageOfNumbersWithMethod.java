public class AverageOfNumbersWithMethod {


    public static double calculateAverageBetweenNumbers(int firstNumber, int lastNumber){

        double sum = 0;
        double average;

        for(int i=firstNumber; i<=lastNumber; i++){
            sum += i;
        }

        average = sum / (lastNumber-firstNumber+1);

        return average;
    }

    public static void main(String args[]) {

        int a;
        int b;

        double avr;

        a = 2;
        b = 11;

        avr = calculateAverageBetweenNumbers(a,b);

        System.out.printf("\nAverage of integers between %d and %d is %.2f",
                a, b, avr);

    }
}

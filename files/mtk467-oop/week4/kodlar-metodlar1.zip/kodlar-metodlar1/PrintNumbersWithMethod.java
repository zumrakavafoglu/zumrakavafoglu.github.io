public class PrintNumbersWithMethod {

    public static void printNumbersInTheInterval(int firstNumber, int lastNumber){

        System.out.printf("\nNumbers from %d to %d are : ",firstNumber, lastNumber);

        for(int i=firstNumber; i<=lastNumber; i++){
            System.out.print(i + " ");
        }
    }

    public static void main(String args[]) {

        int firstNumber;
        int lastNumber;

        firstNumber = 1;
        lastNumber = 7;

        printNumbersInTheInterval(firstNumber, lastNumber);

        firstNumber = 15;
        lastNumber = 29;

        printNumbersInTheInterval(firstNumber, lastNumber);

        firstNumber = 103;
        lastNumber = 147;

        printNumbersInTheInterval(firstNumber, lastNumber);

    }
}
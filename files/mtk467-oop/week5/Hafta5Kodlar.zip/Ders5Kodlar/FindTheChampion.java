
import java.util.Scanner;


public class FindTheChampion {

    public static void main(String args[]) {

        int pointsOfFederer;

        int pointsOfNadal;

        int pointsOfMurray;

        Scanner input = new Scanner(System.in);

        System.out.print("Enter points of Federer: ");

        pointsOfFederer = input.nextInt();

        System.out.print("Enter points of Nadal: ");

        pointsOfNadal = input.nextInt();

        System.out.print("Enter points of Murray: ");

        pointsOfMurray = input.nextInt();

        int maxPoint = MaximumFinder.findMaximum(pointsOfFederer,pointsOfMurray,pointsOfNadal);

        if(maxPoint == pointsOfFederer)
            System.out.printf("Federer is the champion with %d points ", maxPoint);

        if(maxPoint == pointsOfNadal)
            System.out.printf("Nadal is the champion with %d points ", maxPoint);

        if(maxPoint == pointsOfMurray)
            System.out.printf("Murray is the champion with %d points ", maxPoint);

    }
}

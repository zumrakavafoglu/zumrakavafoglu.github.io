
public class MaximumFinder {


    public static void main(String args[]){

        int x = 10;
        int y = 8;
        int z = 25;

        int max;

        max = findMaximum(x,y,z);

        System.out.printf("Maximum of %d, %d and %d is %d", x,y,z,max);

    }


    public static int findMaximum(int number1, int number2, int number3){

        int maximum;

        maximum = number1;

        if(number2 > maximum)
            maximum = number2;

        if(number3 > maximum)
            maximum = number3;

        return maximum;

    }
}

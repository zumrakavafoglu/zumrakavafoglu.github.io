public class MethodOverloadDemo {

    public static int findMaximum(int number1, int number2, int number3){

        int maximum;

        maximum = number1;

        if(number2 > maximum)
            maximum = number2;

        if(number3 > maximum)
            maximum = number3;

        return maximum;

    }

    public static int findMaximum(int number1, int number2){

        int maximum;

        maximum = number1;

        if(number2 > maximum)
            maximum = number2;

        return maximum;

    }


    public static void main(String args[]){

        int x = 10;
        int y = 8;
        int z = 25;

        int maxOfThree = findMaximum(x,y,z);

        System.out.printf("Maximum of %d, %d and %d is %d", x,y,z,maxOfThree);

        int maxOfTwo = findMaximum(x,y);

        System.out.printf("\nMaximum of %d and %d is %d", x,y,maxOfTwo);

    }

}

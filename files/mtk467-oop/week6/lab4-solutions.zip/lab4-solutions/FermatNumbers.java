public class FermatNumbers {
    public static void main(String[] args){
        int fermatNumber;
        int n = 0;
        int multiplicationOfFermats = 1;

        fermatNumber = (int)Math.pow(2,Math.pow(2,n))+1;
       // n++;

        while(fermatNumber <= 10000){

            n++;
            System.out.println("Fermat number is: "+fermatNumber);
            if(fermatNumber == multiplicationOfFermats+2)
                System.out.println("Yes");
            else
                System.out.println("No");

            multiplicationOfFermats *= fermatNumber;
            fermatNumber = (int)Math.pow(2,Math.pow(2,n))+1;
          //  n++;
        }
    }
}

public class Lullaby {
    public static void main(String[] args){

        for(int i=10; i>=1; i--){
            System.out.printf("%d green bottles hanging on a wall,\n",i);
            System.out.printf("%d green bottles hanging on a wall,\n",i);
            System.out.printf("If %d green bottle were to accidentally fall\n",1);
            System.out.printf("There'd be %d green bottles hanging on the wall\n\n",i-1);

        }
    }
}

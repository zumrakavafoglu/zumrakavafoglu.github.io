import java.util.Scanner;

public class MinInput {
    public static void main(String[] args){
        int n;
        int min;

        Scanner input = new Scanner(System.in);

        System.out.println("Input 10 integers: ");
        min = input.nextInt();

        for(int i=0; i<9; i++){
            n = input.nextInt();
            if(n < min){
                min = n;
            }
        }

        System.out.print("Minimum of 10 integers is: "+min);
    }
}

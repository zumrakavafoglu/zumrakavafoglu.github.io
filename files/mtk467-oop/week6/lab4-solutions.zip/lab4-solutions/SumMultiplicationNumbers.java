
public class SumMultiplicationNumbers {

    public static int calculateDigitSum(int n){

        int sum = 0;

        while (n>0){
            sum += n%10;
            n/=10;
        }

        return sum;
    }

    public static int calculateDigitMultiplication(int n){

        int multiplication = 1;

        while (n>0){
            multiplication *= n%10;
            n/=10;
        }

        return multiplication;
    }

    public static boolean isSumMultiplicationNumber(int n){
        return (calculateDigitSum(n) == calculateDigitMultiplication(n));
    }

    public static void main(String args[]){
        for(int i = 1; i <= 10000; i++){
            if(isSumMultiplicationNumber(i))
                System.out.println(i);
        }
    }
}

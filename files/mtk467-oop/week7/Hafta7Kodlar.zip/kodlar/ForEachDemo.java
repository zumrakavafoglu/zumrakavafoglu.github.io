public class ForEachDemo {

    public static void main(String[] args){

        int arr[] = {1, 3, 5, 7, 9};

        for (int value:arr) {
            System.out.println(value);
        }


    }
}

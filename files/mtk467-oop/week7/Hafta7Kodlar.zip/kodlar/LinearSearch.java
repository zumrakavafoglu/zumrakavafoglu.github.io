public class LinearSearch {
    //LinearSearch method, returns -1 if key is not in the array
    //otherwise returns the index of the key element in the array

    public static int linearSearch(int key, int[] arr){
        int n = arr.length;
        for(int i=0; i<n; i++){
            if(key == arr[i]){
                return i;
            }
        }

        return -1;
    }

    public static void main(String[] args){

        int[] intArray = {1, 2, 3, 4, 5, 6, 7, 8, 9};

        int key = 6;

        int keyIndex = linearSearch(key, intArray);

        if( keyIndex != -1)
            System.out.printf("The key element %d is at index %d of the array",key,keyIndex);
        else
            System.out.printf("The key element %d is not found in the array");
    }

}

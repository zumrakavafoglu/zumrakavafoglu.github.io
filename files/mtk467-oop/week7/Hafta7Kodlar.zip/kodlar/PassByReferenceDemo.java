public class PassByReferenceDemo {

    public static void printArray(int[] arr){

        int n = arr.length;

        for(int i=0; i<n; i++)
            System.out.print(arr[i] + " ");
    }

    public static void main(String[] args){

        int x = 7;

        int[] numbers = {1,2,3};

        System.out.println("x: " + x);
        System.out.print("Numbers: ");
        printArray(numbers);
    }

}

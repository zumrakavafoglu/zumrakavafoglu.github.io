public class PassByReferenceDemo2 {

    public static void changeValues(int[] arr, int x ){

        x += 10;

        int n = arr.length;

        for(int i=0; i<n; i++){
            arr[i] += 10;
        }
    }

    public static void main(String[] args){

        int x = 7;

        int[] numberArray = {1, 2, 3};

        changeValues(numberArray,x);

    }
}

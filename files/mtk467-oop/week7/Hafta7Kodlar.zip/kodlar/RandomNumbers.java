import java.util.Scanner;

public class RandomNumbers {

    public static void printArray(double[] arr){

        int n = arr.length;

        for(int i=0; i<n; i++)
            System.out.printf("%.2f  ",arr[i]);
    }

    public static double[] generateRandomNumbers(int n){

        double[] randomNumbers = new double[n];

        for(int i=0; i<n; i++){
            randomNumbers[i] = Math.random();
        }

        return randomNumbers;
    }

    public static void main(String[] args){

        int n;

        System.out.print("How many numbers do you want to generate?: ");

        Scanner input = new Scanner(System.in);

        n = input.nextInt();

        System.out.println("Generated numbers are: ");
        printArray(generateRandomNumbers(n));

    }
}

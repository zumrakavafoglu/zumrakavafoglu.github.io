
    public class SelectionSort
    {
        public static void printArray(int[] arr){

            int n = arr.length;

            for(int i=0; i<n; i++)
                System.out.print(arr[i] + " ");

            System.out.println();
        }

        public static void main(String[] args)
        {
            int[] intArray = {5,1,12,-5,16,2,12,14};

            System.out.println("Unsorted array");
            printArray(intArray);

            selectionSort(intArray);

            System.out.println("Sorted array");
            printArray(intArray);
        }

        public static void swapElements(int[] arr1, int index1, int index2){

            int temp = arr1[index1];
            arr1[index1] = arr1[index2];
            arr1[index2] = temp;
        }

        public static void selectionSort(int[] arr) {
            int i, j, minIndex;
            int n = arr.length;
            for (i = 0; i < n - 1; i++) {
                minIndex = i;
                for (j = i + 1; j < n; j++)
                    if (arr[j] < arr[minIndex])
                        minIndex = j;
                if (minIndex != i) {
                    swapElements(arr,minIndex,i);
                }
            }
        }
    }


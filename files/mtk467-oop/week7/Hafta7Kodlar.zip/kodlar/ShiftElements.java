public class ShiftElements {

    public static void shiftElements(double[] arr){
        double temp = arr[0];

        for (int i = 1; i <arr.length ; i++) {
            arr[i-1] = arr[i];
        }

        arr[arr.length-1] = temp;
    }

    public static void main(String[] args){

        double[] arr = {1.2, 2.1, 3.8, 4.7, 5.9};

        System.out.println("Before shifting: ");
        printArray(arr);

        shiftElements(arr);

        System.out.println("After shifting: ");
        printArray(arr);
    }

    public static void printArray(double[] arr){

        int n = arr.length;

        for(double value: arr)
            System.out.printf("%.2f ", value);

        System.out.print('\n');
    }
}

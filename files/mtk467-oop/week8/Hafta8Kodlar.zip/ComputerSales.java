public class ComputerSales {

    public static void printArray(int[][] arr){
        int rowSize = arr.length;
        int columnSize = arr[0].length;
        for(int i=0; i<rowSize; i++){
            for(int j=0; j<columnSize; j++){
                System.out.print(arr[i][j]+"\t");
            }
            System.out.println();
        }
    }

    public static void main(String[] args){

        int[][] sales = {{15, 7, 3, 0, 12, 10, 4},
                         {3, 8, 7, 6, 1, 11, 2},
                         {1, 17, 3, 9, 10, 1, 1},
                         {2, 6, 7, 5, 18, 25, 20}};

        System.out.println("Daily sales by shops: ");
        printArray(sales);
    }
}

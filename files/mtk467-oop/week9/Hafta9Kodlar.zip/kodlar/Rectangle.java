public class Rectangle {

    double en;
    double boy;

    Rectangle(){
        en = 1;
        boy = 1;
    }

    Rectangle(double _en, double _boy){
        en = _en;
        boy = _boy;
    }

    double findArea(){
        return en*boy;
    }

    double findPerimeter(){
        return 2*(en+boy);
    }
}

public class TestRectangle {

    public static void main(String[] args){
        Rectangle rectangle1 = new Rectangle();

        System.out.println("Rectangle1:");
        System.out.println("En: " + rectangle1.en);
        System.out.println("Boy: " + rectangle1.boy);
        System.out.println("Alan: " + rectangle1.findArea());
        System.out.println("Cevre: " + rectangle1.findPerimeter());

        Rectangle rectangle2 = new Rectangle(2,3);

        System.out.println("Rectangle2:");
        System.out.println("En: " + rectangle2.en);
        System.out.println("Boy: " + rectangle2.boy);
        System.out.println("Alan: " + rectangle2.findArea());
        System.out.println("Cevre: " + rectangle2.findPerimeter());


    }
}

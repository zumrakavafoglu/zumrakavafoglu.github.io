package packagePassReference;

public class TestChangingObject {

	public static void main(String[] args) {
		Circle myCircle = new Circle();
		
		int n=5;
		printAreas(myCircle, n);
		
		System.out.println("\nRadius is "+myCircle.radius);
		System.out.println("n is "+n);
	}
	
	static void printAreas(Circle c, int times)
	{
		System.out.println("Radius\t\tArea");
		while(times>=1)
		{
			System.out.println(c.radius + "\t\t" + c.findArea());
			c.radius++;
			times--;
		}
	}
}



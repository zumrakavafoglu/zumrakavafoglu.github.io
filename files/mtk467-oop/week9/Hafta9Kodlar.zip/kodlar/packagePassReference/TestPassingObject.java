package packagePassReference;

public class TestPassingObject {

	public static void main(String[] args) {
		Circle myCircle = new Circle(5.0);
		printCircle(myCircle);
	}
	
	static void printCircle(Circle c)
	{
		System.out.println("The area of the circle of radius " + c.radius+ " is "+c.findArea());
	}
}


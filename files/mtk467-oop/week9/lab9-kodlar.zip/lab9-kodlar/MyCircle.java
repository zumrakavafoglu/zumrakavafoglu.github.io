public class MyCircle {

    //Eksik metotlari tamamlayiniz.

    private MyPoint center;
    private int radius;

    public MyCircle(){
        center = new MyPoint();
        radius = 1;
    }

    public MyCircle(int _x, int _y, int _radius){
        center = new MyPoint(_x,_y);
        setRadius(_radius);
    }

    public void setRadius(int _radius){
        if(_radius <= 0){
            System.out.println("Wrong radius, set to 1");
            radius = 1;
        }else{
            radius = _radius;
        }
    }

    public int getRadius(){
        return radius;
    }

    public void setCenter(MyPoint _center){
        center = _center;
    }

    public MyPoint getCenter() {
        return center;
    }

    public int getCenterX(){
        return center.getX();
    }

    public void setCenterX(int _x){
        center.setX(_x);
    }

    public double getArea(){
        return Math.PI * radius * radius;
    }

    public double distance(MyCircle another){
        return center.distance(another.getCenter());
    }
}

public class MyPoint {

    private int x;
    private int y;

    public MyPoint(){
        x = 0;
        y = 0;
    }

    public MyPoint(int _x, int _y){
        setXY(_x,_y);
    }

    public void setX(int _x){
        x = _x;
    }

    public void setY(int _y){
        y = _y;
    }

    public void setXY(int _x, int _y){
        setX(_x);
        setY(_y);
    }

    public int getX(){
        return x;
    }

    public int getY(){
        return y;
    }

    public int[] getXY(){
        int[] xy = {x,y};
        return xy;
    }

    public String toString() {
        String s = "(" + x + "," + y + ")";
        return s;
    }

    public double distance(int _x, int _y){
        double dist = Math.sqrt( Math.pow(x-_x,2) + Math.pow(y-_y,2));
        return dist;
    }

    public double distance(){
        return distance(0,0);
    }

    public double distance(MyPoint another){
        return distance(another.getX(), another.getY());
    }

}

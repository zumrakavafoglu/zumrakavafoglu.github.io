public class TestMyPoint {
    public static void main(String[] args){
        MyPoint myPoint1 = new MyPoint(2,5);
        MyPoint myPoint2 = new MyPoint(1,3);

        System.out.println(myPoint1);
        System.out.println(myPoint2);

        double d = myPoint1.distance(myPoint2);
        System.out.println("Distance between myPoint1 and myPoint2: "+d);

        double distToOrigin = myPoint1.distance();
        System.out.println("Distance of myPoint1 to origin: "+distToOrigin);

        double dist2 = myPoint1.distance(4,7);
        System.out.println("Distance of myPoint1 to (4,7): "+dist2);

        int[] xyOfPoint1 = myPoint1.getXY();
    }
}
